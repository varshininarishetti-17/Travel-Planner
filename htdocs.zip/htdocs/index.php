<?php
// Include database connection
include 'includes/db.php'; 
include 'includes/guest_header.php'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Planner | Explore the World</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    
    <style>
        /* --- CSS VARIABLES & RESET --- */
        :root {
            --primary: #2e7d32;
            --secondary: #ffa000;
            --dark: #212121;
            --light: #f4f4f9;
            --white: #ffffff;
            --shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            line-height: 1.6;
            background-color: var(--white);
            color: var(--dark);
        }

        /* --- NAVIGATION --- */
        nav {
            background: var(--white);
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 5%;
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo { font-weight: 600; font-size: 1.5rem; color: var(--primary); }
        .nav-links { list-style: none; display: flex; }
        .nav-links li { margin-left: 20px; }
        .nav-links a { text-decoration: none; color: var(--dark); font-weight: 400; transition: 0.3s; }
        .nav-links a:hover { color: var(--primary); }

        /* --- HERO SECTION --- */
        .hero {
            background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), 
                        url('https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            height: 80vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            color: var(--white);
            padding: 0 20px;
        }

        .hero h1 { font-size: 3.5rem; margin-bottom: 1rem; }
        .hero p { font-size: 1.2rem; margin-bottom: 2rem; max-width: 600px; }

        .search-box {
            background: var(--white);
            padding: 10px;
            border-radius: 50px;
            display: flex;
            width: 100%;
            max-width: 500px;
            box-shadow: var(--shadow);
        }

        .search-box input {
            border: none;
            padding: 10px 20px;
            flex: 1;
            border-radius: 50px;
            outline: none;
        }

        .search-box button {
            background: var(--primary);
            color: white;
            border: none;
            padding: 10px 25px;
            border-radius: 50px;
            cursor: pointer;
            transition: 0.3s;
        }

        .search-box button:hover { background: #1b5e20; }

        /* --- SECTION STYLING --- */
        .section { padding: 80px 10%; text-align: center; }
        .bg-light { background-color: var(--light); }
        .section h2 { font-size: 2.5rem; margin-bottom: 40px; position: relative; }
        .section h2::after {
            content: '';
            width: 60px;
            height: 3px;
            background: var(--secondary);
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
        }

        /* --- GRID & CARDS --- */
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 20px;
        }

        .card {
            background: var(--white);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: transform 0.3s;
            text-align: left;
        }

        .card:hover { transform: translateY(-10px); }

        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .card-content { padding: 20px; }
        .card-content h3 { margin-bottom: 10px; color: var(--primary); }
        .card-content p { font-size: 0.9rem; color: #666; margin-bottom: 15px; }

        .btn {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-primary { background: var(--primary); color: white; }
        .btn-success { background: var(--secondary); color: white; }
        .btn:hover { opacity: 0.8; }

        /* --- ABOUT SECTION --- */
        .about-text { max-width: 800px; margin: 0 auto 30px; font-size: 1.1rem; }

        /* --- FOOTER --- */
        footer {
            background: var(--dark);
            color: white;
            padding: 40px 10%;
            text-align: center;
        }

        @media (max-width: 768px) {
            .hero h1 { font-size: 2.2rem; }
            .nav-links { display: none; } /* Hide nav on mobile for simplicity */
        }
        /* --- MODERN PACKAGE CARDS --- */
.packages-section {
    padding: 40px 0;
}

.travel-card {
    background: #ffffff;
    border-radius: 20px;
    overflow: hidden;
    box-shadow: 0 10px 25px rgba(0,0,0,0.06);
    transition: all 0.4s ease;
    border: 1px solid #f0f0f0;
}

.travel-card:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.12);
}

/* Image Styling */
.image-wrapper {
    position: relative;
    height: 230px;
    overflow: hidden;
}

.image-wrapper img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.6s ease;
}

.travel-card:hover .image-wrapper img {
    transform: scale(1.1);
}

/* Price Badge Overlay */
.price-badge {
    position: absolute;
    bottom: 15px;
    left: 15px;
    background: var(--primary);
    color: white;
    padding: 6px 15px;
    border-radius: 50px;
    font-weight: 600;
    font-size: 0.9rem;
    box-shadow: 0 4px 10px rgba(0,0,0,0.2);
}

/* Content Styling */
.card-content {
    padding: 20px;
}

.destination-tag {
    font-size: 0.75rem;
    color: #888;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 600;
    display: block;
    margin-bottom: 8px;
}

.card-content h3 {
    font-size: 1.25rem;
    color: #2c3e50;
    margin-bottom: 15px;
    font-weight: 600;
    line-height: 1.4;
}

/* Footer & Button Styling */
.card-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: 1px solid #f5f5f5;
    padding-top: 15px;
}

.rating {
    font-size: 0.85rem;
    color: #555;
    font-weight: 500;
}

.book-btn {
    background: #1a1a1a;
    color: white !important;
    text-decoration: none;
    padding: 10px 18px;
    border-radius: 12px;
    font-size: 0.85rem;
    font-weight: 600;
    transition: 0.3s;
}

.book-btn:hover {
    background: var(--secondary);
    color: white !important;
}

.no-data {
    grid-column: 1 / -1;
    text-align: center;
    padding: 50px;
    color: #999;
}
    </style>
</head>
<body>

<section class="hero">
    <h1>Explore the Unexplored</h1>
    <p>Hand-picked magical destinations and tailored travel packages just for you.</p>

    <form method="GET" action="destinations.php" class="search-box">
        <input type="text" name="search" placeholder="Where do you want to go?" required>
        <button type="submit">Search</button>
    </form>
</section>

<section class="section">
    <h2>Popular Destinations</h2>
    <div class="grid-container">
        <?php
        // Fetch real data from the 'destination' table
        $stmt = $conn->prepare("SELECT id, name, description, image FROM destination ORDER BY created_at DESC LIMIT 3");
        $stmt->execute();
        $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($destinations):
            foreach ($destinations as $dest): 
        ?>
            <div class="card">
                <img src="images/<?= htmlspecialchars($dest['image']) ?>" 
                     alt="<?= htmlspecialchars($dest['name']) ?>"
                     onerror="this.src='https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=500&q=60'">
                <div class="card-content">
                    <h3><?= htmlspecialchars($dest['name']) ?></h3>
                    <p><?= substr(htmlspecialchars($dest['description']), 0, 100) ?>...</p>
                    <a href="destination_detail.php?id=<?= $dest['id'] ?>" class="btn btn-primary">View More</a>
                </div>
            </div>
        <?php 
            endforeach; 
        else:
            echo "<p>No destinations available.</p>";
        endif; 
        ?>
    </div>
</section>

<section class="section">
    <h2>Popular Packages</h2>
    <div class="grid-container">
        <?php
        // Fetch real data without the 'status' filter
        $stmt = $conn->prepare("
            SELECT p.id, p.name, p.price, p.image, d.name AS destination_name 
            FROM packages p 
            LEFT JOIN destination d ON p.destination_id = d.id 
            ORDER BY p.created_at DESC LIMIT 3
        ");
        $stmt->execute();
        $packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($packages):
            foreach ($packages as $pkg):
        ?>
            <div class="travel-card">
                <div class="image-wrapper">
                    <img src="images/<?= htmlspecialchars($pkg['image'] ?? '') ?>" 
                         alt="<?= htmlspecialchars($pkg['name'] ?? 'Package') ?>"
                         onerror="this.src='https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=500&q=60'">
                    <div class="price-badge">$<?= number_format((float)$pkg['price'], 0) ?></div>
                </div>
                
                <div class="card-content">
                    <span class="destination-tag">
                        <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($pkg['destination_name'] ?? 'Global') ?>
                    </span>
                    <h3><?= htmlspecialchars($pkg['name']) ?></h3>
                    <div class="card-footer">
                        <span class="rating">
                            <i class="fas fa-star" style="color: #ffa000;"></i> 4.8 (24 Reviews)
                        </span>
                        <a href="package_detail.php?id=<?= $pkg['id'] ?>" class="book-btn">Book Now</a>
                    </div>
                </div>
            </div>
        <?php 
            endforeach; 
        else:
            echo "<div class='no-data'>No packages found in the database.</div>";
        endif;
        ?>
    </div>
</section>

<section class="section">
    <h2>Why Choose Us?</h2>
    <p class="about-text">
        With over 10 years of experience, we provide seamless travel planning, 
        24/7 customer support, and exclusive deals you won't find anywhere else.
    </p>
    <a href="about.php" class="btn btn-primary" style="background: var(--secondary)">Learn More</a>
</section>

<footer>
    <p>&copy; <?= date('Y') ?> Travel Planner Travel Agency. All Rights Reserved.</p>
</footer>

</body>
</html>