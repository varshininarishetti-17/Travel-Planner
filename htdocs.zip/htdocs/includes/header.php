<?php
// Start session safely
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Travel Experts | Your Premium Travel Planner</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        :root {
            --primary: #007BFF;
            --danger: #e74c3c;
            --dark: #1a1a1a;
            --white: #ffffff;
            --gray: #555;
            --shadow: 0 4px 12px rgba(0,0,0,0.08);
            --transition: all 0.3s ease;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            color: #333;
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background: var(--white);
            box-shadow: var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
            padding: 12px 0;
        }

        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        /* Logo Styling */
        .logo {
            font-size: 1.5rem;
            font-weight: 700;
            text-decoration: none;
            color: var(--dark);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo span { color: var(--primary); }

        nav {
            display: flex;
            align-items: center;
        }

        nav a {
            text-decoration: none;
            color: var(--gray);
            margin-left: 22px;
            font-weight: 500;
            transition: var(--transition);
            font-size: 0.95rem;
        }

        nav a:hover { color: var(--primary); }

        /* Highlight for the page you are on */
        .active { color: var(--primary); font-weight: 700; }

        /* CTA & Logout Buttons */
        .btn-cta {
            background: var(--primary);
            color: white !important;
            padding: 9px 22px;
            border-radius: 50px;
        }

        .btn-cta:hover { background: #0056b3; box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3); }

        .logout-link {
            color: var(--danger) !important;
            font-weight: 600;
        }

        /* User Profile Section */
        .user-section {
            display: flex;
            align-items: center;
            margin-left: 20px;
            padding-left: 20px;
            border-left: 1px solid #eee;
        }

        .user-greeting {
            font-size: 0.85rem;
            color: #888;
            margin-right: 15px;
        }

        .user-greeting strong { color: var(--dark); }

        main { flex: 1; }

        /* Responsive Design */
        @media (max-width: 992px) {
            nav a { margin-left: 15px; font-size: 0.85rem; }
        }

        @media (max-width: 768px) {
            .nav-container { flex-direction: column; gap: 15px; }
            nav { flex-wrap: wrap; justify-content: center; }
            nav a { margin: 5px 10px; }
            .user-section { border: none; margin: 0; padding: 0; }
        }
    </style>
</head>
<body>

<header>
    <div class="nav-container">
        <a href="index.php" class="logo">
            <i class="fas fa-paper-plane"></i> Travel<span>Planner</span>
        </a>

        <nav>
            <a href="dashboard.php">Home</a>
            <a href="destinations.php">Destinations</a>
            <a href="packages.php">Packages</a>
            <a href="blog.php">Blog</a>
            <a href="profile.php">Profile</a>

            <?php if (isset($_SESSION['user_id'])): ?>
                <div class="user-section">
                    <span class="user-greeting">Hi, <strong><?= htmlspecialchars($_SESSION['user_name']) ?></strong></span>
                    <a href="logout.php" class="logout-link">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
              </div>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="contact.php" class="btn-cta">Contact Us</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
