<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TravelPlanner - Welcome</title>
    <style>
        /* Minimalist Reset & Variables */
        :root {
            --primary-color: #2ecc71;
            --dark-color: #1a1a1a;
            --light-bg: #f8f9fa;
        }

        body {
            margin: 0;
            font-family: 'Inter', -apple-system, sans-serif;
            background-color: var(--light-bg);
        }

        /* Header Styling */
        .guest-header {
            background: #ffffff;
            padding: 15px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .logo {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--dark-color);
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo span {
            color: var(--primary-color);
        }

        .guest-nav {
            display: flex;
            gap: 20px;
            align-items: center;
        }

        .nav-link {
            text-decoration: none;
            color: #666;
            font-weight: 500;
            font-size: 0.95rem;
            transition: color 0.3s;
        }

        .nav-link:hover {
            color: var(--primary-color);
        }

        .btn-auth {
            padding: 10px 24px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: 0.3s;
        }

        .btn-login {
            color: var(--dark-color);
            border: 1px solid #ddd;
        }

        .btn-login:hover {
            background: #f0f0f0;
        }

        .btn-register {
            background: var(--primary-color);
            color: white;
            border: 1px solid var(--primary-color);
        }

        .btn-register:hover {
            background: #27ae60;
            box-shadow: 0 4px 12px rgba(46, 204, 113, 0.2);
        }

        @media (max-width: 600px) {
            .guest-header { padding: 15px 20px; }
            .nav-link { display: none; } /* Hide "Home" on mobile to save space */
        }
    </style>
</head>
<body>

<header class="guest-header">
    <a href="index.php" class="logo">
        Travel<span>Planner</span>
    </a>

    <nav class="guest-nav">
        <a href="index.php" class="nav-link">Home</a>
        
        <?php 
        // Get current filename to toggle buttons
        $current_page = basename($_SERVER['PHP_SELF']); 
        ?>

        <?php if ($current_page !== 'login.php'): ?>
            <a href="login.php" class="btn-auth btn-login">Login</a>
        <?php endif; ?>

        <?php if ($current_page !== 'register.php'): ?>
            <a href="register.php" class="btn-auth btn-register">Sign Up</a>
        <?php endif; ?>
    </nav>
</header>