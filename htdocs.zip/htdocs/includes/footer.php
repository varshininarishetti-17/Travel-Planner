<style>
    /* --- Modern Footer Styling --- */
    footer {
        background-color: #1a1a1a;
        color: #ffffff;
        padding: 60px 20px 20px;
        margin-top: 80px;
        font-family: 'Inter', sans-serif;
    }

    .footer-container {
        max-width: 1200px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 40px;
        border-bottom: 1px solid #333;
        padding-bottom: 40px;
    }

    .footer-section h4 {
        color: #007BFF;
        margin-bottom: 20px;
        font-size: 1.2rem;
        font-weight: 600;
    }

    .footer-section p {
        color: #999;
        font-size: 0.9rem;
        line-height: 1.6;
    }

    .footer-links {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .footer-links li {
        margin-bottom: 12px;
    }

    .footer-links a {
        color: #999;
        text-decoration: none;
        font-size: 0.9rem;
        transition: color 0.3s ease;
    }

    .footer-links a:hover {
        color: #ffffff;
    }

    .social-icons {
        display: flex;
        gap: 15px;
        margin-top: 15px;
    }

    .social-icons a {
        background: #333;
        width: 35px;
        height: 35px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        color: #fff;
        text-decoration: none;
        font-size: 0.8rem;
        transition: background 0.3s ease;
    }

    .social-icons a:hover {
        background: #007BFF;
    }

    .copyright {
        text-align: center;
        padding-top: 25px;
        color: #666;
        font-size: 0.85rem;
    }

    /* Responsive adjustments */
    @media (max-width: 768px) {
        .footer-container {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 480px) {
        .footer-container {
            grid-template-columns: 1fr;
            text-align: center;
        }
        .social-icons {
            justify-content: center;
        }
    }
</style>

<footer>
    <div class="footer-container">
        <div class="footer-section">
            <h4>Travel Experts</h4>
            <p>Your trusted partner for curated travel experiences and unforgettable adventures across the globe.</p>
            <div class="social-icons">
                <a href="#">FB</a>
                <a href="#">IG</a>
                <a href="#">TW</a>
            </a>
        </div>

        <div class="footer-section">
            <h4>Quick Links</h4>
            <ul class="footer-links">
                <li><a href="index.php">Home</a></li>
                <li><a href="destinations.php">Destinations</a></li>
                <li><a href="packages.php">Travel Packages</a></li>
                <li><a href="about.php">About Us</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h4>Support</h4>
            <ul class="footer-links">
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">Terms of Service</a></li>
                <li><a href="contact.php">Contact Us</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h4>Contact Info</h4>
            <p>123 Travel Lane,<br>Adventure City, AC 45678</p>
            <p>Email: info@travelexperts.com<br>Phone: +1 (555) 000-1234</p>
        </div>
    </div>

    <div class="copyright">
        <p>&copy; <?php echo date("Y"); ?> Travel Experts. All rights reserved.</p>
    </div>
</footer>

</body>
</html>