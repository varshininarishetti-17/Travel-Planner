<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// If the session role isn't 'admin', kick them out to login
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../login.php?error=unauthorized");
    exit;
}
?>