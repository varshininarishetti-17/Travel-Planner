<?php
$host = "sql208.infinityfree.com";
$db_name = "if0_41512143_travel_db";
$username = "if0_41512143";    // Change if needed
$password = "MeenalY123";        // Change if needed

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>