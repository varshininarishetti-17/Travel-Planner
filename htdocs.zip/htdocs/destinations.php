<?php
// 1. Session and Cookie Management
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please_Login");
    exit(); // Always call exit() after a header redirect
}
// Start session to track user login status

// Set a cookie to remember the last search term for 30 days
if (!empty($_GET['search'])) {
    setcookie("last_search", $_GET['search'], time() + (86400 * 30), "/"); 
}

// 2. Core Requirements
require_once 'includes/db.php';     // Database connection ($conn)
include 'includes/header.php'; // Navigation header

// 3. Search Logic
$isSearch = !empty($_GET['search']);
$searchTerm = $isSearch ? trim($_GET['search']) : '';

// If user isn't searching now, but has a cookie, we could use it to show "Recently searched"
$suggestedSearch = isset($_COOKIE['last_search']) ? $_COOKIE['last_search'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explore Destinations | Travel Experts</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #007BFF;
            --accent-color: #0056b3;
            --bg-light: #f8f9fa;
            --text-dark: #333;
            --text-muted: #666;
            --white: #ffffff;
            --shadow: 0 10px 20px rgba(0,0,0,0.08);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #fff;
            color: var(--text-dark);
            margin: 0;
            padding: 0;
        }

        /* --- Hero Section --- */
        .search-hero {
            padding: 80px 20px;
            text-align: center;
            background: linear-gradient(135deg, #f1f3f5 0%, #e9ecef 100%);
            border-bottom: 1px solid #dee2e6;
        }

        .search-hero h1 {
            font-size: 2.8rem;
            margin-bottom: 25px;
            font-weight: 700;
            letter-spacing: -0.5px;
        }

        .search-container {
            display: flex;
            justify-content: center;
            max-width: 650px;
            margin: 0 auto;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 18px 30px;
            font-size: 1.1rem;
            border: 2px solid transparent;
            border-radius: 50px;
            box-shadow: var(--shadow);
            outline: none;
            transition: var(--transition);
        }

        .search-input:focus {
            border-color: var(--primary-color);
            background: var(--white);
        }

        .search-btn {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            padding: 12px 28px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 40px;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }

        .search-btn:hover { background-color: var(--accent-color); }

        .recent-search-text {
            margin-top: 15px;
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        /* --- Grid Layout --- */
        .content-section {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 1.8rem;
            border-left: 5px solid var(--primary-color);
            padding-left: 15px;
            margin: 0;
        }

        .destinations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 35px;
        }

        /* --- Card Styling --- */
        .dest-card {
            background: var(--white);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.04);
            transition: var(--transition);
            border: 1px solid #f1f1f1;
            display: flex;
            flex-direction: column;
        }

        .dest-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow);
        }

        .image-wrapper {
            position: relative;
            height: 240px;
            overflow: hidden;
        }

        .image-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .location-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(255, 255, 255, 0.95);
            color: var(--text-dark);
            padding: 6px 14px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
        }

        .card-body {
            padding: 25px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .details-link {
            margin-top: auto;
            text-align: center;
            padding: 14px;
            background-color: #f8f9fa;
            color: var(--text-dark);
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            transition: var(--transition);
        }

        .details-link:hover {
            background-color: var(--primary-color);
            color: white;
        }

        .empty-state {
            text-align: center;
            grid-column: 1 / -1;
            padding: 80px 20px;
        }
    </style>
</head>
<body>

<header class="search-hero">
    <h1>Find Your Next Adventure</h1>
    
    <form method="GET" action="destinations.php" class="search-container">
        <input type="text" name="search" class="search-input" 
               placeholder="Search destinations..." 
               value="<?= htmlspecialchars($searchTerm) ?>" required>
        <button type="submit" class="search-btn"><i class="fas fa-search"></i></button>
    </form>

    <?php if ($suggestedSearch && !$isSearch): ?>
        <p class="recent-search-text">Last time you looked for: <strong><?= htmlspecialchars($suggestedSearch) ?></strong></p>
    <?php endif; ?>
</header>

<main class="content-section">
    <div class="section-header">
        <h2 class="section-title">
            <?= $isSearch ? "Search Results" : "Top Destinations"; ?>
        </h2>
        <?php if($isSearch): ?>
            <a href="destinations.php" style="color: var(--primary-color); text-decoration: none; font-weight: 600;">← Clear Search</a>
        <?php endif; ?>
    </div>

    <div class="destinations-grid">
        <?php
        try {
            // Using 'destination' (singular) to match your previous SQL inserts
            if ($isSearch) {
                $query = "SELECT * FROM destination WHERE name LIKE :search OR description LIKE :search ORDER BY id DESC";
                $stmt = $conn->prepare($query);
                $stmt->execute(['search' => "%$searchTerm%"]);
            } else {
                $query = "SELECT * FROM destination ORDER BY id DESC";
                $stmt = $conn->query($query);
            }

            if ($stmt && $stmt->rowCount() > 0) {
                while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    $imgSrc = !empty($row['image']) ? "images/".htmlspecialchars($row['image']) : "images/default.jpg";
                    ?>
                    <article class="dest-card">
                        <div class="image-wrapper">
                            <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($row['name']) ?>">
                            <div class="location-badge">
                                <i class="fas fa-map-marker-alt"></i> Trending
                            </div>
                        </div>
                        <div class="card-body">
                            <h3><?= htmlspecialchars($row['name']) ?></h3>
                            <p><?= htmlspecialchars(substr($row['description'], 0, 100)) ?>...</p>
                            
                            <?php if(isset($_SESSION['user_id'])): ?>
                                <a href="destination_detail.php?id=<?= $row['id'] ?>" class="details-link">Explore More</a>
                            <?php else: ?>
                                <a href="login.php" class="details-link" style="background: #ffeeba;">Login to See Deals</a>
                            <?php endif; ?>
                        </div>
                    </article>
                    <?php
                }
            } else {
                echo "<div class='empty-state'>
                        <i class='fas fa-search-minus' style='font-size: 3rem; color: #ccc;'></i>
                        <h3>No matches found.</h3>
                        <a href='destinations.php'>View All Destinations</a>
                      </div>";
            }
        } catch (PDOException $e) {
            echo "<div class='empty-state'><p>Error: " . $e->getMessage() . "</p></div>";
        }
        ?>
    </div>
</main>

<?php include 'includes/footer.php'; ?>

</body>
</html>