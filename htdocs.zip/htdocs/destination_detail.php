<?php
/**
 * DESTINATION DETAIL PAGE
 * Handles: 
 * - Session tracking for form persistence
 * - Cookie tracking for "Recently Viewed"
 * - Dynamic retrieval of linked 'packages' based on destination_id
 */

// 1. Initialize Sessions (MUST be at the very top)
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please_Login");
    exit(); // Always call exit() after a header redirect
}

// 2. Database Connection
require_once 'includes/db.php';
include 'includes/header.php';

// 3. ID Validation
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $destination_id = (int)$_GET['id'];

    // 4. Fetch Destination Details
    $stmt = $conn->prepare("SELECT * FROM destination WHERE id = :id");
    $stmt->execute(['id' => $destination_id]);
    $destination = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$destination) {
        echo "<div style='text-align:center; padding:100px;'><h2>Destination not found.</h2><a href='packages.php'>Back to Explore</a></div>";
        include 'includes/footer.php';
        exit;
    }

    // --- COOKIE LOGIC ---
    // Stores the name of this destination in the user's browser for 30 days
    // Used to show the "Welcome back" message on return visits
    setcookie("last_viewed_dest", $destination['name'], time() + (86400 * 30), "/");

    // 5. Fetch Related Packages (Linked Data Interaction)
    // This pulls all entries from the 'packages' table where the destination_id matches
    $stmtPackages = $conn->prepare("SELECT * FROM packages WHERE destination_id = :id ORDER BY created_at DESC");
    $stmtPackages->execute(['id' => $destination_id]);
    $packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);

    // 6. Handle Rating Submission (POST Interaction)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_rating'])) {
        $user_name = htmlspecialchars(trim($_POST['user_name']));
        $rating    = (int)$_POST['rating'];
        $comment   = htmlspecialchars(trim($_POST['comment']));

        if (!empty($user_name) && !empty($comment)) {
            // --- SESSION LOGIC ---
            // Remembers the user's name so they don't have to re-type it for the next review
            $_SESSION['reviewer_name'] = $user_name;

            $stmtInsert = $conn->prepare("INSERT INTO destination_ratings (destination_id, user_name, rating, comment) VALUES (:destination_id, :user_name, :rating, :comment)");
            $stmtInsert->execute([
                'destination_id' => $destination_id,
                'user_name'      => $user_name,
                'rating'         => $rating,
                'comment'        => $comment
            ]);
            
            // Redirect to refresh the list and prevent duplicate POST on page reload
            echo "<script>alert('Review submitted!'); window.location.href='destination_detail.php?id=$destination_id';</script>";
            exit;
        }
    }

    // 7. Fetch All Ratings for this Destination
    $stmtRatings = $conn->prepare("SELECT * FROM destination_ratings WHERE destination_id = :id ORDER BY created_at DESC");
    $stmtRatings->execute(['id' => $destination_id]);
    $ratings = $stmtRatings->fetchAll(PDO::FETCH_ASSOC);

} else {
    echo "<div style='text-align:center; padding:100px;'><h2>No destination selected.</h2></div>";
    include 'includes/footer.php';
    exit;
}
?>

<?php if(isset($_COOKIE['last_viewed_dest']) && $_COOKIE['last_viewed_dest'] != $destination['name']): ?>
    <div style="background:#d1ecf1; color:#0c5460; padding:12px; text-align:center; font-family: sans-serif; font-size:0.9rem; border-bottom: 1px solid #bee5eb;">
        👋 Welcome back! Last time you explored <strong><?php echo htmlspecialchars($_COOKIE['last_viewed_dest']); ?></strong>.
    </div>
<?php endif; ?>

<section style="max-width:1000px; margin:40px auto; padding:0 20px;">
    <h1 style="font-size:3rem; margin-bottom:10px; color:#1a1a1a;"><?php echo htmlspecialchars($destination['name']); ?></h1>
    
    <div style="position:relative; margin-bottom:30px;">
        <img src="images/<?php echo !empty($destination['image']) ? $destination['image'] : 'default-dest.jpg'; ?>" 
             alt="<?php echo htmlspecialchars($destination['name']); ?>" 
             style="width:100%; border-radius:20px; height:500px; object-fit:cover; box-shadow:0 15px 40px rgba(0,0,0,0.15);">
    </div>
    
    <div style="line-height:1.8; color:#444; font-size:1.15rem; background:white; padding:30px; border-radius:15px; border:1px solid #eee;">
        <h3 style="margin-top:0;">About this Destination</h3>
        <?php echo nl2br(htmlspecialchars($destination['description'])); ?>
    </div>
</section>

<section style="padding:80px 20px; background:#f4f7f6;">
    <div style="max-width:1000px; margin:auto;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:40px;">
            <h2 style="margin:0;">Exclusive Adventure Packages</h2>
            <span style="background:#2ecc71; color:white; padding:5px 15px; border-radius:50px; font-size:0.8rem; font-weight:bold;">
                <?php echo count($packages); ?> Deals Available
            </span>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap:30px;">
            <?php if ($packages): ?>
                <?php foreach ($packages as $pkg): ?>
                    <div style="background:#fff; border-radius:15px; overflow:hidden; box-shadow:0 5px 15px rgba(0,0,0,0.05); transition:0.3s; border:1px solid #eee;">
                        <img src="images/<?php echo htmlspecialchars($pkg['image']); ?>" style="width:100%; height:200px; object-fit:cover;">
                        <div style="padding:20px;">
                            <h3 style="margin:0 0 10px 0; font-size:1.25rem;"><?php echo htmlspecialchars($pkg['name']); ?></h3>
                            <div style="display:flex; justify-content:space-between; align-items:center;">
                                <span style="font-weight:bold; color:#2ecc71; font-size:1.4rem;">$<?php echo number_format($pkg['price'], 2); ?></span>
                                <span style="color:#888; font-size:0.85rem;">⏱ <?php echo htmlspecialchars($pkg['duration']); ?></span>
                            </div>
                            <a href="package_detail.php?id=<?php echo $pkg['id']; ?>" 
                               style="display:block; text-align:center; margin-top:20px; padding:12px; background:#1a1a1a; color:#fff; text-decoration:none; border-radius:8px; font-weight:600; transition:0.3s;">
                               View Package
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div style="grid-column: 1/-1; text-align:center; padding:50px; background:white; border-radius:15px;">
                    <p style="color:#888;">No packages currently available for this specific destination.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section style="max-width:1000px; margin:auto; padding:80px 20px;">
    <h2 style="margin-bottom:40px;">Traveler Reviews</h2>
    
    <div style="display:grid; grid-template-columns: 1fr 350px; gap:50px;">
        <div>
            <?php if ($ratings): ?>
                <?php foreach ($ratings as $rate): ?>
                    <div style="background:#fff; border: 1px solid #eee; border-radius:12px; padding:20px; margin-bottom:20px;">
                        <div style="color:#f1c40f; margin-bottom:10px; font-size:0.9rem;">
                            <?php echo str_repeat("★", $rate['rating']) . str_repeat("☆", 5 - $rate['rating']); ?>
                        </div>
                        <strong style="display:block; margin-bottom:5px;"><?php echo htmlspecialchars($rate['user_name']); ?></strong>
                        <p style="color:#555; font-size:0.95rem; line-height:1.5;"><?php echo nl2br(htmlspecialchars($rate['comment'])); ?></p>
                        <small style="color:#bbb; font-size:0.75rem;">Posted on <?php echo date('F j, Y', strtotime($rate['created_at'])); ?></small>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color:#999; font-style:italic;">No reviews yet. Be the first to share your journey!</p>
            <?php endif; ?>
        </div>

        <div style="position: sticky; top: 20px; height: fit-content; background:#fff; border:1px solid #eee; padding:30px; border-radius:15px; box-shadow:0 10px 30px rgba(0,0,0,0.05);">
            <h3 style="margin-top:0;">Leave a Review</h3>
            <form method="POST">
                <label style="font-size:0.85rem; font-weight:bold; color:#666;">Your Name</label>
                <input type="text" name="user_name" 
                       placeholder="Enter your name" 
                       value="<?php echo isset($_SESSION['reviewer_name']) ? htmlspecialchars($_SESSION['reviewer_name']) : ''; ?>" 
                       required style="width:100%; padding:12px; margin:8px 0 20px; border:1px solid #ddd; border-radius:8px; box-sizing: border-box;">
                
                <label style="font-size:0.85rem; font-weight:bold; color:#666;">Rating</label>
                <select name="rating" required style="width:100%; padding:12px; margin:8px 0 20px; border:1px solid #ddd; border-radius:8px; background:white;">
                    <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
                    <option value="4">⭐⭐⭐⭐ Good</option>
                    <option value="3">⭐⭐⭐ Average</option>
                    <option value="2">⭐⭐ Fair</option>
                    <option value="1">⭐ Poor</option>
                </select>
                
                <label style="font-size:0.85rem; font-weight:bold; color:#666;">Comment</label>
                <textarea name="comment" placeholder="Describe your experience..." required style="width:100%; padding:12px; height:120px; margin:8px 0 20px; border:1px solid #ddd; border-radius:8px; resize:none; box-sizing: border-box;"></textarea>
                
                <button type="submit" name="submit_rating" style="width:100%; padding:14px; background:#007BFF; color:#fff; border:none; border-radius:8px; font-weight:bold; cursor:pointer; font-size:1rem;">
                    Submit My Review
                </button>
            </form>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>