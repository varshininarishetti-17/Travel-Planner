<?php
include 'includes/db.php';
include 'includes/header.php';

// 1. Validate the ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<section style='padding:100px; text-align:center;'><h2>No blog post selected.</h2><a href='blog.php'>Back to Blog</a></section>";
    include 'includes/footer.php';
    exit;
}

$blog_id = $_GET['id'];

// 2. Handle comment submission (BEFORE fetching data)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_comment'])) {
    $user_name = trim($_POST['user_name']);
    $comment = trim($_POST['comment']);

    if (!empty($user_name) && !empty($comment)) {
        $stmtInsert = $conn->prepare("INSERT INTO blog_comments (blog_id, user_name, comment) VALUES (:blog_id, :user_name, :comment)");
        $stmtInsert->execute([
            'blog_id' => $blog_id,
            'user_name' => $user_name,
            'comment' => $comment
        ]);
        
        // Redirect to the same page to prevent "Form Resubmission" on refresh
        header("Location: blog_detail.php?id=" . $blog_id . "&success=1");
        exit;
    }
}

// 3. Fetch blog post details
$stmt = $conn->prepare("
    SELECT bp.*, bc.name AS category_name
    FROM blog_posts bp
    LEFT JOIN blog_categories bc ON bp.category_id = bc.id
    WHERE bp.id = :id
");
$stmt->execute(['id' => $blog_id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$post) {
    echo "<section style='padding:100px; text-align:center;'><h2>Blog post not found.</h2><a href='blog.php'>Back to Blog</a></section>";
    include 'includes/footer.php';
    exit;
}

// 4. Fetch comments
$stmtComments = $conn->prepare("SELECT * FROM blog_comments WHERE blog_id = :blog_id ORDER BY created_at DESC");
$stmtComments->execute(['blog_id' => $blog_id]);
$comments = $stmtComments->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    .article-container { max-width: 850px; margin: 40px auto; padding: 0 20px; line-height: 1.8; }
    .post-header { margin-bottom: 30px; text-align: center; }
    .post-meta { color: #888; font-size: 0.9rem; margin-bottom: 20px; }
    .post-image { width: 100%; border-radius: 15px; box-shadow: var(--shadow); margin-bottom: 30px; }
    .comment-section { background: var(--light); padding: 50px 0; border-top: 1px solid #eee; }
    .comment-card { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
    .comment-form input, .comment-form textarea { width: 100%; padding: 12px; margin-bottom: 15px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; }
    .btn-submit { background: var(--primary); color: white; border: none; padding: 12px 30px; border-radius: 50px; cursor: pointer; font-weight: 600; }
</style>

<article class="article-container">
    <div class="post-header">
        <a href="blog.php" style="text-decoration:none; color:var(--primary); font-weight:600;">← Back to Blog</a>
        <h1 style="font-size: 2.5rem; margin-top:15px;"><?= htmlspecialchars($post['title']); ?></h1>
        <div class="post-meta">
            <i class="far fa-user"></i> By <?= htmlspecialchars($post['author']); ?> | 
            <i class="far fa-folder"></i> <?= htmlspecialchars($post['category_name']); ?> | 
            <i class="far fa-calendar"></i> <?= date('F j, Y', strtotime($post['created_at'])); ?>
        </div>
    </div>

    <img src="images/<?= htmlspecialchars($post['image']); ?>" alt="<?= htmlspecialchars($post['title']); ?>" class="post-image">

    <div class="post-content" style="font-size: 1.1rem; color: #444;">
        <?= nl2br(htmlspecialchars($post['content'])); ?>
    </div>
</article>

<section class="comment-section">
    <div class="article-container">
        <h2>Comments (<?= count($comments) ?>)</h2>
        
        <?php if (isset($_GET['success'])): ?>
            <p style="background: #d4edda; color: #155724; padding: 15px; border-radius: 8px;">Success! Your comment has been posted.</p>
        <?php endif; ?>

        <div style="margin: 30px 0;">
            <?php if ($comments): ?>
                <?php foreach ($comments as $c): ?>
                    <div class="comment-card">
                        <strong><?= htmlspecialchars($c['user_name']) ?></strong> 
                        <small style="color:#aaa; margin-left:10px;"><?= date('M j, Y', strtotime($c['created_at'])) ?></small>
                        <p style="margin-top:10px; color:#555;"><?= nl2br(htmlspecialchars($c['comment'])) ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No comments yet. Be the first to share your thoughts!</p>
            <?php endif; ?>
        </div>

        <div style="background:white; padding:30px; border-radius:15px; box-shadow:var(--shadow);">
            <h3>Leave a Comment</h3>
            <form method="POST" action="" class="comment-form">
                <input type="text" name="user_name" placeholder="Your Name" required>
                <textarea name="comment" placeholder="Your comment..." required style="height:120px;"></textarea>
                <button type="submit" name="submit_comment" class="btn-submit">Post Comment</button>
            </form>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>