<?php
session_start();

// 1. SECURITY: Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

require_once 'includes/db.php';
include 'includes/header.php';

$user_id = $_SESSION['user_id'];
$message = "";

// 2. ACTION: CANCEL BOOKING (Only if Pending)
if (isset($_POST['cancel_booking'])) {
    $booking_id = $_POST['booking_id'];
    // Extra security: Ensure the booking belongs to THIS user and is still Pending
    $stmt = $conn->prepare("UPDATE bookings SET status = 'Cancelled' WHERE id = :bid AND user_id = :uid AND status = 'Pending'");
    if ($stmt->execute(['bid' => $booking_id, 'uid' => $user_id])) {
        $message = "Your booking has been cancelled successfully.";
    }
}

// 3. FETCH USER'S BOOKINGS
$query = "SELECT b.*, p.name as package_name, p.image as package_img, p.price 
          FROM bookings b 
          JOIN packages p ON b.package_id = p.id 
          WHERE b.user_id = :uid 
          ORDER BY b.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->execute(['uid' => $user_id]);
$my_bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    :root {
        --primary: #3498db;
        --success: #2ecc71;
        --warning: #f1c40f;
        --danger: #e74c3c;
        --light: #f4f7f6;
    }

    .profile-container { max-width: 1000px; margin: 50px auto; padding: 20px; font-family: 'Segoe UI', sans-serif; }
    .profile-header { margin-bottom: 30px; border-bottom: 2px solid #eee; padding-bottom: 10px; }
    
    .booking-card { 
        display: flex; background: white; border-radius: 15px; overflow: hidden; 
        box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 20px; transition: 0.3s;
    }
    .booking-card:hover { transform: translateY(-5px); box-shadow: 0 8px 25px rgba(0,0,0,0.1); }
    
    .booking-img { width: 200px; object-fit: cover; }
    
    .booking-info { padding: 20px; flex: 1; position: relative; }
    .booking-info h3 { margin: 0 0 10px; color: #2c3e50; }
    
    /* Status Badges */
    .status-badge { 
        position: absolute; top: 20px; right: 20px; 
        padding: 5px 15px; border-radius: 50px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase;
    }
    .status-Pending { background: #fff3cd; color: #856404; }
    .status-Confirmed { background: #d4edda; color: #155724; }
    .status-Cancelled { background: #f8d7da; color: #721c24; }

    .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 15px; }
    .detail-item { font-size: 0.9rem; color: #666; }
    .detail-item i { color: var(--primary); margin-right: 8px; width: 15px; }

    .btn-cancel { 
        background: none; border: 1px solid var(--danger); color: var(--danger); 
        padding: 5px 12px; border-radius: 5px; cursor: pointer; font-size: 0.8rem; margin-top: 15px;
    }
    .btn-cancel:hover { background: var(--danger); color: white; }

    .empty-state { text-align: center; padding: 50px; color: #999; }
    .alert { background: #d4edda; color: #155724; padding: 15px; border-radius: 10px; margin-bottom: 20px; }
</style>

<div class="profile-container">
    <div class="profile-header">
        <h1>My Travel Bookings</h1>
        <p>Welcome back! Here is the status of your current and past requests.</p>
    </div>

    <?php if ($message): ?>
        <div class="alert"><?= $message ?></div>
    <?php endif; ?>

    <?php if (empty($my_bookings)): ?>
        <div class="empty-state">
            <i class="fas fa-plane-departure" style="font-size: 3rem; margin-bottom: 20px;"></i>
            <p>You haven't made any bookings yet.</p>
            <a href="index.php" class="btn-book" style="text-decoration:none; display:inline-block; margin-top:10px;">Explore Packages</a>
        </div>
    <?php else: ?>
        <?php foreach ($my_bookings as $booking): ?>
            <div class="booking-card">
                <img src="images/<?= htmlspecialchars($booking['package_img']) ?>" class="booking-img" onerror="this.src='https://images.unsplash.com/photo-1503220317375-aaad61436b1b?auto=format&fit=crop&w=500&q=60'">
                
                <div class="booking-info">
                    <span class="status-badge status-<?= $booking['status'] ?>">
                        <?= $booking['status'] ?>
                    </span>
                    
                    <h3><?= htmlspecialchars($booking['package_name']) ?></h3>
                    
                    <div class="details-grid">
                        <div class="detail-item">
                            <i class="fas fa-calendar-alt"></i> 
                            <strong>Travel Date:</strong> <?= date("M d, Y", strtotime($booking['travel_date'])) ?>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-users"></i> 
                            <strong>Travelers:</strong> <?= $booking['num_people'] ?>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-tag"></i> 
                            <strong>Total Cost:</strong> $<?= number_format($booking['price'] * $booking['num_people'], 2) ?>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-clock"></i> 
                            <strong>Requested on:</strong> <?= date("M d, Y", strtotime($booking['created_at'])) ?>
                        </div>
                    </div>

                    <?php if ($booking['status'] === 'Pending'): ?>
                        <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this booking request?');">
                            <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
                            <button type="submit" name="cancel_booking" class="btn-cancel">Cancel Request</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>