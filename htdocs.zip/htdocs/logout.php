<?php
// 1. Initialize the session to access it
session_start();

// 2. Unset all session variables
$_SESSION = array();

// 3. If you want to kill the session cookie (the browser's link to the session)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Destroy the session on the server
session_destroy();

/**
 * OPTIONAL: Clear the "Recently Viewed" Cookie
 * If you want the website to "forget" the user entirely, 
 * uncomment the line below:
 */
// setcookie("last_viewed_dest", "", time() - 3600, "/");

// 5. Redirect the user back to the login page or home page
header("Location: login.php?logout=success");
exit;
?>