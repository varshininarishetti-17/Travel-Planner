<?php
/**
 * TRAVEL EXPERTS - MAIN DASHBOARD (INDEX)
 * Logic: Checks session, retrieves top 3 destinations and top 3 packages.
 */
session_start();
require_once 'includes/db.php';
include 'includes/header.php';

// 1. Security Check: Redirect to login if the session is empty
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['user_name'];

// 2. Data Retrieval
// Fetch Top 3 Destinations (ordered by newest)
$destStmt = $conn->query("SELECT * FROM destination ORDER BY id DESC LIMIT 3");
$top_destinations = $destStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Top 3 Packages (joined with destination names)
$pkgStmt = $conn->query("SELECT p.*, d.name as dest_name FROM packages p 
                         JOIN destination d ON p.destination_id = d.id 
                         ORDER BY p.id DESC LIMIT 3");
$top_packages = $pkgStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    /* --- HERO SECTION --- */
    .dashboard-hero {
        background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.85)), url('images/hero-landscape.jpg');
        background-size: cover; 
        background-position: center;
        color: white; 
        padding: 80px 50px;
        border-radius: 0 0 50px 50px;
        height: 450px; 
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        align-items: flex-start;
        text-align: left;
    }
    .hero-text h1 { margin: 0; font-size: 3.5rem; font-weight: 800; line-height: 1.1; text-shadow: 0 4px 15px rgba(0,0,0,0.4); }
    .hero-text p { margin: 15px 0 0; font-size: 1.3rem; font-weight: 300; opacity: 0.95; }
    .hero-text::before { content: ""; display: block; width: 60px; height: 4px; background: #007BFF; margin-bottom: 20px; border-radius: 2px; }

    /* --- DETAILED INTRO --- */
    .detailed-intro { max-width: 900px; margin: 60px auto; padding: 0 20px; text-align: center; }
    .detailed-intro h2 { font-size: 2.2rem; color: #1a1a1a; margin-bottom: 20px; }
    .detailed-intro p { font-size: 1.1rem; color: #555; line-height: 1.8; }

    /* --- GRID SYSTEM (Left to Right) --- */
    .section-container { max-width: 1200px; margin: 60px auto; padding: 0 20px; }
    .section-title { 
        display: flex; justify-content: space-between; align-items: center; 
        margin-bottom: 30px; border-left: 5px solid #007BFF; padding-left: 15px;
    }
    .grid { 
        display: grid; 
        grid-template-columns: repeat(3, 1fr); /* Forces 3 items across */
        gap: 30px; 
    }

    /* --- DESTINATION CARDS --- */
    .dest-card {
        position: relative; border-radius: 20px; overflow: hidden; height: 350px;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1); transition: 0.3s; cursor: pointer;
    }
    .dest-card:hover { transform: translateY(-10px); }
    .dest-card img { width: 100%; height: 100%; object-fit: cover; }
    .dest-overlay {
        position: absolute; bottom: 0; width: 100%; padding: 25px;
        background: linear-gradient(transparent, rgba(0,0,0,0.9)); color: white;
    }

    /* --- PACKAGE CARDS --- */
    .pkg-card {
        background: white; border-radius: 20px; overflow: hidden;
        border: 1px solid #eee; transition: 0.3s; display: flex; flex-direction: column;
    }
    .pkg-card:hover { box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
    .pkg-card img { width: 100%; height: 220px; object-fit: cover; }
    .pkg-content { padding: 20px; flex-grow: 1; }
    .pkg-price { font-size: 1.4rem; font-weight: bold; color: #2ecc71; }
    
    .btn-main {
        display: inline-block; padding: 10px 20px; background: #007BFF; 
        color: white; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 0.9rem;
    }

    /* --- STATS SECTION --- */
    .stats-section { max-width: 1100px; margin: 80px auto; padding: 0 20px; }
    .stats-bar {
        display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;
        background: #fff; padding: 40px; border-radius: 25px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.05); border: 1px solid #f0f0f0;
    }
    .stat-item { text-align: center; position: relative; }
    .stat-item:not(:last-child)::after {
        content: ""; position: absolute; right: -10px; top: 20%; height: 60%; width: 1px; background: #eee;
    }
    .stat-icon { font-size: 1.5rem; margin-bottom: 10px; display: block; }
    .stat-item h3 { font-size: 2rem; margin: 0; color: #1a1a1a; }
    .stat-item p { color: #7f8c8d; text-transform: uppercase; font-size: 0.8rem; letter-spacing: 1px; }

    /* Responsive */
    @media (max-width: 992px) { .grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 768px) {
        .grid, .stats-bar { grid-template-columns: 1fr; }
        .stat-item:after { display: none; }
        .hero-text h1 { font-size: 2.5rem; }
    }
</style>

<div class="dashboard-hero">
    <div class="hero-text">
        <h1>Welcome Home,<br><?= htmlspecialchars($user_name) ?></h1>
        <p>Your journey of a thousand miles begins here.</p>
    </div>
</div>

<section class="detailed-intro">
    <h2>Explore the World with Travel Experts</h2>
    <p>
        Travel Experts is your personal architect for unforgettable experiences. 
        Whether you are seeking the quiet serenity of a mountain retreat or the 
        vibrant energy of a metropolitan escape, we handle the logistics so you 
        can focus on making memories that last a lifetime.
    </p>
    <div style="margin-top: 30px;">
        <a href="destinations.php" class="btn-main">Explore All Destinations</a>
    </div>
</section>

<section class="section-container">
    <div class="section-title">
        <h2>Trending Destinations</h2>
        <a href="destinations.php" style="color: #007BFF; text-decoration: none; font-weight: bold;">View All →</a>
    </div>
    <div class="grid">
        <?php foreach($top_destinations as $dest): ?>
            <div class="dest-card" onclick="window.location.href='destination_detail.php?id=<?= $dest['id'] ?>'">
                <img src="images/<?= $dest['image'] ?>" alt="<?= $dest['name'] ?>">
                <div class="dest-overlay">
                    <h3><?= htmlspecialchars($dest['name']) ?></h3>
                    <p style="font-size: 0.85rem; opacity: 0.8;">Discover the magic of <?= htmlspecialchars($dest['name']) ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="section-container" style="background: #fcfcfc; padding: 60px 20px; border-radius: 40px;">
    <div class="section-title">
        <h2>Popular Travel Packages</h2>
        <a href="packages.php" style="color: #007BFF; text-decoration: none; font-weight: bold;">Browse All Deals →</a>
    </div>
    <div class="grid">
        <?php foreach($top_packages as $pkg): ?>
            <div class="pkg-card">
                <img src="images/<?= $pkg['image'] ?>" alt="<?= $pkg['name'] ?>">
                <div class="pkg-content">
                    <span style="font-size: 0.75rem; color: #888; text-transform: uppercase;"><?= htmlspecialchars($pkg['dest_name']) ?></span>
                    <h3 style="margin: 8px 0; font-size: 1.2rem;"><?= htmlspecialchars($pkg['name']) ?></h3>
                    <p style="color: #666; font-size: 0.85rem; margin-bottom: 20px;">⏱ <?= htmlspecialchars($pkg['duration']) ?></p>
                    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f0f0f0; padding-top: 15px;">
                        <span class="pkg-price">$<?= number_format($pkg['price'], 2) ?></span>
                        <a href="package_detail.php?id=<?= $pkg['id'] ?>" class="btn-main">Details</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<div class="stats-section">
    <div class="stats-bar">
        <div class="stat-item">
            <span class="stat-icon">🤝</span>
            <h3>50+</h3>
            <p>Global Partners</p>
        </div>
        <div class="stat-item">
            <span class="stat-icon">😊</span>
            <h3>15k</h3>
            <p>Happy Travelers</p>
        </div>
        <div class="stat-item">
            <span class="stat-icon">🎧</span>
            <h3>24/7</h3>
            <p>Expert Support</p>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>