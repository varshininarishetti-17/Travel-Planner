<?php
// Start session for admin check if needed
if (session_status() === PHP_SESSION_NONE) { session_start(); }

include 'includes/db.php';
include 'includes/header.php';

// --- 1. UPDATE LOGIC ---
$message = "";
if (isset($_POST['update_status'])) {
    $booking_id = $_POST['booking_id'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE bookings SET status = :status WHERE id = :id");
    if ($stmt->execute(['status' => $status, 'id' => $booking_id])) {
        $message = "Status updated to $status successfully!";
    }
}

// --- 2. DATA FETCH ---
$stmt = $conn->query("
    SELECT b.*, p.name AS package_name
    FROM bookings b
    LEFT JOIN packages p ON b.package_id = p.id
    ORDER BY b.created_at DESC
");
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    :root {
        --primary: #007BFF;
        --success: #2ecc71;
        --warning: #f1c40f;
        --danger: #e74c3c;
        --light-bg: #f8f9fa;
    }

    body { background-color: var(--light-bg); }

    .admin-container {
        max-width: 1200px;
        margin: 50px auto;
        padding: 0 20px;
    }

    .admin-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    /* Table Styling */
    .table-wrapper {
        background: white;
        padding: 25px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.95rem;
    }

    th {
        text-align: left;
        padding: 15px;
        color: #888;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.75rem;
        border-bottom: 2px solid #f0f0f0;
    }

    td {
        padding: 18px 15px;
        border-bottom: 1px solid #f9f9f9;
        vertical-align: middle;
    }

    /* Status Badges */
    .status-badge {
        padding: 5px 12px;
        border-radius: 50px;
        font-size: 0.75rem;
        font-weight: 700;
    }
    .status-Pending { background: #fff4de; color: #ffa800; }
    .status-Confirmed { background: #e1f9ec; color: #2ecc71; }
    .status-Cancelled { background: #fff0f0; color: #e74c3c; }

    /* Action Form */
    .update-form {
        display: flex;
        gap: 8px;
    }

    select {
        padding: 8px;
        border-radius: 8px;
        border: 1px solid #ddd;
        font-size: 0.85rem;
    }

    .btn-update {
        background: var(--primary);
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 8px;
        cursor: pointer;
        font-weight: 600;
        transition: 0.2s;
    }

    .btn-update:hover { background: #0056b3; }

    .alert-msg {
        background: #e1f9ec;
        color: #2ecc71;
        padding: 15px;
        border-radius: 12px;
        margin-bottom: 20px;
        text-align: center;
        font-weight: 600;
    }
</style>

<div class="admin-container">
    <div class="admin-header">
        <h1><i class="fas fa-clipboard-list"></i> Booking Management</h1>
        <p style="color: #666;">Total Bookings: <strong><?= count($bookings) ?></strong></p>
    </div>

    <?php if ($message): ?>
        <div class="alert-msg"><?= $message ?></div>
    <?php endif; ?>

    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Customer</th>
                    <th>Package</th>
                    <th>Travel Date</th>
                    <th>Pax</th>
                    <th>Status</th>
                    <th>Update Action</th>
                    <th>Booked On</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($bookings): ?>
                    <?php foreach ($bookings as $b): ?>
                        <tr>
                            <td>
                                <strong><?= htmlspecialchars($b['user_name'] ?? 'Guest') ?></strong><br>
                                <span style="font-size: 0.8rem; color: #999;"><?= htmlspecialchars($b['user_email'] ?? 'N/A') ?></span>
                            </td>
                            <td>
                                <span style="font-weight: 600; color: var(--primary);"><?= htmlspecialchars($b['package_name']) ?></span>
                            </td>
                            <td><i class="far fa-calendar-alt"></i> <?= date("M d, Y", strtotime($b['travel_date'])) ?></td>
                            <td><?= $b['num_people'] ?></td>
                            <td>
                                <span class="status-badge status-<?= $b['status'] ?>">
                                    <?= $b['status'] ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" class="update-form">
                                    <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                                    <select name="status">
                                        <option value="Pending" <?= $b['status']=='Pending'?'selected':'' ?>>Pending</option>
                                        <option value="Confirmed" <?= $b['status']=='Confirmed'?'selected':'' ?>>Confirmed</option>
                                        <option value="Cancelled" <?= $b['status']=='Cancelled'?'selected':'' ?>>Cancelled</option>
                                    </select>
                                    <button type="submit" name="update_status" class="btn-update">Save</button>
                                </form>
                            </td>
                            <td style="color: #bbb; font-size: 0.8rem;">
                                <?= date("Y-m-d H:i", strtotime($b['created_at'])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align:center; padding: 50px; color: #ccc;">
                            <i class="fas fa-folder-open" style="font-size: 3rem; display: block; margin-bottom: 10px;"></i>
                            No bookings found in the database.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>