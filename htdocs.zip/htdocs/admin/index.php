<?php
// Secure the session and check admin status
if (session_status() === PHP_SESSION_NONE) { session_start(); }

include '../includes/db.php';
include '../includes/admin_check.php'; // Important: Ensures only admins can see this
include 'admin_header.php';

// 1. Fetch live stats from the database
$dest_count = $conn->query("SELECT COUNT(*) FROM destination")->fetchColumn();
$pack_count = $conn->query("SELECT COUNT(*) FROM packages")->fetchColumn();
$blog_count = $conn->query("SELECT COUNT(*) FROM blog_posts")->fetchColumn();
$book_count = $conn->query("SELECT COUNT(*) FROM bookings WHERE status = 'Pending'")->fetchColumn();
?>

<style>
    :root {
        --admin-primary: #4e73df;
        --admin-success: #1cc88a;
        --admin-info: #36b9cc;
        --admin-warning: #f6c23e;
        --bg-light: #f8f9fc;
    }

    body { background-color: var(--bg-light); font-family: 'Inter', sans-serif; }

    .admin-wrapper {
        max-width: 1200px;
        margin: 40px auto;
        padding: 0 20px;
    }

    .page-title {
        font-size: 1.8rem;
        font-weight: 800;
        color: #3a3b45;
        margin-bottom: 30px;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    /* --- STAT CARDS GRID --- */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr); /* 4 columns left-to-right */
        gap: 20px;
        margin-bottom: 40px;
    }

    .stat-card {
        background: white;
        padding: 25px;
        border-radius: 15px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        border-left: 5px solid;
        transition: transform 0.2s;
        text-decoration: none;
        display: block;
    }

    .stat-card:hover { transform: translateY(-5px); box-shadow: 0 8px 20px rgba(0,0,0,0.1); }

    .stat-label {
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 5px;
    }

    .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #5a5c69;
    }

    /* Column-specific colors */
    .border-dest { border-left-color: var(--admin-primary); }
    .label-dest { color: var(--admin-primary); }

    .border-pack { border-left-color: var(--admin-success); }
    .label-pack { color: var(--admin-success); }

    .border-blog { border-left-color: var(--admin-warning); }
    .label-blog { color: var(--admin-warning); }

    .border-book { border-left-color: var(--admin-info); }
    .label-book { color: var(--admin-info); }

    /* Quick Links Section */
    .management-section {
        background: white;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }

    .quick-list {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 15px;
        margin-top: 20px;
    }

    .quick-btn {
        padding: 15px;
        background: #f8f9fc;
        border: 1px solid #e3e6f0;
        border-radius: 10px;
        text-decoration: none;
        color: #4e73df;
        font-weight: 600;
        text-align: center;
        transition: 0.3s;
    }

    .quick-btn:hover { background: #4e73df; color: white; }

    @media (max-width: 1024px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 600px) { .stats-grid { grid-template-columns: 1fr; } }
</style>

<div class="admin-wrapper">
    <div class="page-title">
        <i class="fas fa-tachometer-alt"></i> Control Panel
    </div>

    <div class="stats-grid">
        <a href="manage_destinations.php" class="stat-card border-dest">
            <div class="stat-label label-dest">Total Destinations</div>
            <div class="stat-value"><?= $dest_count ?></div>
        </a>

        <a href="manage_packages.php" class="stat-card border-pack">
            <div class="stat-label label-pack">Active Packages</div>
            <div class="stat-value"><?= $pack_count ?></div>
        </a>

        <a href="admin_bookings.php" class="stat-card border-book">
            <div class="stat-label label-book">Pending Bookings</div>
            <div class="stat-value"><?= $book_count ?></div>
        </a>

        <a href="manage_blog.php" class="stat-card border-blog">
            <div class="stat-label label-blog">Total Articles</div>
            <div class="stat-value"><?= $blog_count ?></div>
        </a>
    </div>

    <div class="management-section">
        <h3><i class="fas fa-tools"></i> Management Tools</h3>
        <p style="color: #888; font-size: 0.9rem;">Quickly access your administrative tasks below.</p>
        
        <div class="quick-list">
            <a href="manage_destinations.php" class="quick-btn">Manage Destinations</a>
            <a href="manage_packages.php" class="quick-btn">Manage Packages</a>
            <a href="admin_bookings.php" class="quick-btn">Manage Bookings</a>
            <a href="manage_blog.php" class="quick-btn">Manage Blog</a>
            <a href="manage_users.php" class="quick-btn">User Accounts</a>
            <a href="../index.php" class="quick-btn" style="color: #666;">View Live Site</a>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>