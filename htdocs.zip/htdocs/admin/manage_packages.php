<?php
include '../includes/db.php';
include '../includes/admin_check.php';
include 'admin_header.php';

// --- DELETE LOGIC ---
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->prepare("DELETE FROM packages WHERE id = ?")->execute([$id]);
    header("Location: manage_packages.php");
}

// --- ADD LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_pack'])) {
    $dest_id = $_POST['destination_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $dur = $_POST['duration'];
    $img = $_FILES['image']['name'];
    
    move_uploaded_file($_FILES['image']['tmp_name'], "../images/packages/".$img);

    $sql = "INSERT INTO packages (destination_id, name, price, duration, image) VALUES (?, ?, ?, ?, ?)";
    $conn->prepare($sql)->execute([$dest_id, $name, $price, $dur, $img]);
}

$destList = $conn->query("SELECT id, name FROM destination")->fetchAll();
$packages = $conn->query("SELECT p.*, d.name as d_name FROM packages p JOIN destination d ON p.destination_id = d.id")->fetchAll();
?>

<div style="margin-left:270px; padding:20px;">
    <h1>Travel Packages</h1>

    <div style="background:#f4f4f4; padding:20px; border-radius:10px; margin-bottom:30px;">
        <h3>Create New Package</h3>
        <form method="POST" enctype="multipart/form-data" style="display:grid; gap:10px;">
            <select name="destination_id" required style="padding:10px;">
                <option value="">-- Link to Destination Site --</option>
                <?php foreach($destList as $dl): ?>
                    <option value="<?= $dl['id'] ?>"><?= $dl['name'] ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="name" placeholder="Package Title (e.g. Honeymoon Special)" required style="padding:10px;">
            <input type="number" name="price" placeholder="Price (USD)" required style="padding:10px;">
            <input type="text" name="duration" placeholder="Duration (e.g. 3 Days)" style="padding:10px;">
            <input type="file" name="image" required>
            <button type="submit" name="add_pack" style="background:blue; color:white; padding:12px; border:none; cursor:pointer;">Publish Package</button>
        </form>
    </div>

    <table style="width:100%; border-collapse:collapse; background:white;">
        <tr style="background:#333; color:white; text-align:left;">
            <th style="padding:10px;">Package Name</th>
            <th>Site</th>
            <th>Price</th>
            <th>Action</th>
        </tr>
        <?php foreach($packages as $p): ?>
        <tr style="border-bottom:1px solid #ddd;">
            <td style="padding:10px;"><?= htmlspecialchars($p['name']) ?></td>
            <td><?= htmlspecialchars($p['d_name']) ?></td>
            <td>$<?= number_format($p['price'], 2) ?></td>
            <td><a href="manage_packages.php?delete=<?= $p['id'] ?>" style="color:red;">Delete</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>