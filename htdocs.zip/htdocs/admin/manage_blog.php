<?php
// 1. Initialize Sessions and Security
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// Adjust paths based on your folder structure (assuming this is in an /admin/ folder)
require_once '../includes/db.php';
require_once '../includes/admin_check.php'; 
include 'admin_header.php';

$message = "";

// 2. DELETE ACTION
if (isset($_POST['delete_post'])) {
    $post_id = $_POST['post_id'];
    
    // Optional: Fetch image name to delete file from server
    $imgStmt = $conn->prepare("SELECT image FROM blog_posts WHERE id = ?");
    $imgStmt->execute([$post_id]);
    $imgData = $imgStmt->fetch();
    if($imgData && !empty($imgData['image'])) {
        @unlink("../images/" . $imgData['image']);
    }

    $stmt = $conn->prepare("DELETE FROM blog_posts WHERE id = :id");
    if ($stmt->execute(['id' => $post_id])) {
        $message = "Article deleted successfully.";
    }
}

// 3. TOGGLE STATUS ACTION (Draft/Published)
if (isset($_POST['toggle_status'])) {
    $post_id = $_POST['post_id'];
    $current_status = $_POST['status'];
    $new_status = ($current_status == 'Published') ? 'Draft' : 'Published';
    
    $stmt = $conn->prepare("UPDATE blog_posts SET status = :status WHERE id = :id");
    if($stmt->execute(['status' => $new_status, 'id' => $post_id])) {
        $message = "Post status updated to $new_status.";
    }
}

// 4. FETCH ALL POSTS (Removed the 'Published' filter so Admin can see Drafts)
$query = "SELECT bp.*, bc.name AS category_name 
          FROM blog_posts bp
          LEFT JOIN blog_categories bc ON bp.category_id = bc.id
          ORDER BY bp.created_at DESC";

$posts = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
    :root {
        --primary-admin: #3498db;
        --success-admin: #2ecc71;
        --danger-admin: #e74c3c;
        --dark-admin: #2c3e50;
    }

    .admin-container { max-width: 1200px; margin: 40px auto; padding: 0 20px; font-family: 'Inter', sans-serif; }
    
    .page-header { 
        display: flex; justify-content: space-between; align-items: center; 
        margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 20px;
    }

    .btn-create {
        background: var(--success-admin); color: white; text-decoration: none;
        padding: 12px 25px; border-radius: 8px; font-weight: 600;
        transition: 0.3s; display: inline-flex; align-items: center; gap: 8px;
    }
    .btn-create:hover { background: #27ae60; transform: translateY(-2px); color: white; }

    /* Table Styling */
    .blog-card { background: white; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f8f9fa; padding: 15px; text-align: left; font-size: 0.8rem; color: #888; text-transform: uppercase; letter-spacing: 1px; }
    td { padding: 20px 15px; border-bottom: 1px solid #f1f1f1; vertical-align: middle; }

    .post-preview-img { width: 60px; height: 60px; object-fit: cover; border-radius: 8px; background: #eee; border: 1px solid #ddd; }
    
    /* Status Pill Styling */
    .status-pill {
        padding: 6px 14px; border-radius: 20px; font-size: 0.7rem; font-weight: 700;
        display: inline-block; cursor: pointer; border: none; text-transform: uppercase;
    }
    .status-Published { background: #e1f9ec; color: #2ecc71; border: 1px solid #2ecc71; }
    .status-Draft { background: #fdf2f2; color: #666; border: 1px solid #ddd; }

    .action-icons { display: flex; gap: 15px; }
    .action-link { color: #555; text-decoration: none; font-size: 1.1rem; transition: 0.2s; }
    .edit-link:hover { color: var(--primary-admin); }
    .delete-btn { background: none; border: none; color: var(--danger-admin); cursor: pointer; padding: 0; font-size: 1.1rem; }
    .delete-btn:hover { color: #c0392b; }

    .alert { 
        background: #e8f5e9; color: #2e7d32; padding: 15px; border-radius: 8px; 
        margin-bottom: 20px; border-left: 5px solid #2e7d32; font-weight: 500;
        animation: fadeIn 0.5s ease;
    }

    @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
</style>

<div class="admin-container">
    <div class="page-header">
        <div>
            <h1>Manage Blog Articles</h1>
            <p style="color: #666;">View, edit, and moderate your travel stories.</p>
        </div>
        <a href="create_post.php" class="btn-create">
            <i class="fas fa-plus"></i> Write New Post
        </a>
    </div>

    <?php if ($message): ?>
        <div class="alert" id="success-alert"><?= $message ?></div>
    <?php endif; ?>

    <div class="blog-card">
        <table>
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Title & Info</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($posts as $post): ?>
                <tr>
                    <td style="width: 80px;">
                        <img src="../images/<?= htmlspecialchars($post['image'] ?? '') ?>" 
                             class="post-preview-img" 
                             onerror="this.src='https://via.placeholder.com/60x60?text=No+Img'">
                    </td>
                    <td>
                        <strong style="font-size: 1rem; color: var(--dark-admin);"><?= htmlspecialchars($post['title']) ?></strong><br>
                        <span style="font-size: 0.8rem; color: #7f8c8d;">
                            <i class="far fa-folder"></i> <?= htmlspecialchars($post['category_name'] ?? 'Uncategorized') ?> | 
                            <i class="far fa-calendar-alt"></i> <?= date("M d, Y", strtotime($post['created_at'])) ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                            <input type="hidden" name="status" value="<?= $post['status'] ?>">
                            <button type="submit" name="toggle_status" class="status-pill status-<?= $post['status'] ?>" title="Click to change status">
                                <?= $post['status'] ?>
                            </button>
                        </form>
                    </td>
                    <td>
                        <div class="action-icons">
                            <a href="edit_post.php?id=<?= $post['id'] ?>" class="action-link edit-link" title="Edit Content">
                                <i class="fas fa-edit"></i>
                            </a>
                            
                            <form method="POST" onsubmit="return confirm('Wait! Are you sure you want to delete this article? This cannot be undone.');" style="display:inline;">
                                <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                                <button type="submit" name="delete_post" class="delete-btn" title="Delete Permanently">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>

                            <a href="../blog_detail.php?id=<?= $post['id'] ?>" target="_blank" class="action-link" title="View Live Version">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                
                <?php if (empty($posts)): ?>
                    <tr>
                        <td colspan="4" style="text-align:center; padding: 80px; color: #bdc3c7;">
                            <i class="fas fa-feather-alt" style="font-size: 4rem; margin-bottom: 20px; display: block; opacity: 0.3;"></i>
                            <h3>No articles found</h3>
                            <p>Your blog is empty. Click "Write New Post" to get started!</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Auto-hide success messages after 4 seconds
    const alertBox = document.getElementById('success-alert');
    if (alertBox) {
        setTimeout(() => {
            alertBox.style.transition = "opacity 0.6s ease";
            alertBox.style.opacity = "0";
            setTimeout(() => alertBox.remove(), 600);
        }, 4000);
    }
</script>

<?php include '../includes/footer.php'; ?>