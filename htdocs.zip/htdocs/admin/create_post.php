<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

include '../includes/db.php';
include '../includes/admin_check.php'; 
include 'admin_header.php';

$message = "";
$error = "";

// --- HANDLE FORM SUBMISSION ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_post'])) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $status = $_POST['status'];
    $author = $_SESSION['user_name'] ?? 'Admin';

    // Image Upload Logic
    $image_name = $_FILES['image']['name'];
    $target_dir = "../images/";
    $target_file = $target_dir . basename($image_name);
    $upload_ok = true;

    // Basic Validation
    if (empty($title) || empty($content)) {
        $error = "Title and Content are required.";
        $upload_ok = false;
    }

    if ($upload_ok) {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            // Save to Database
            $stmt = $conn->prepare("INSERT INTO blog_posts (title, content, image, author, status, created_at) 
                                   VALUES (:title, :content, :image, :author, :status, NOW())");
            
            if ($stmt->execute([
                'title' => $title,
                'content' => $content,
                'image' => $image_name,
                'author' => $author,
                'status' => $status
            ])) {
                header("Location: manage_blog.php?msg=PostCreated");
                exit;
            }
        } else {
            $error = "Failed to upload image. Please check folder permissions.";
        }
    }
}
?>

<style>
    .admin-container { max-width: 900px; margin: 40px auto; padding: 0 20px; font-family: 'Inter', sans-serif; }
    
    .editor-card {
        background: white;
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.08);
    }

    .form-group { margin-bottom: 25px; }
    
    label { 
        display: block; 
        margin-bottom: 10px; 
        font-weight: 700; 
        color: #333; 
        font-size: 0.9rem;
        text-transform: uppercase;
    }

    .form-control {
        width: 100%;
        padding: 15px;
        border: 2px solid #f0f0f0;
        border-radius: 10px;
        font-size: 1rem;
        transition: 0.3s;
        box-sizing: border-box;
    }

    .form-control:focus { border-color: #3498db; outline: none; background: #fff; }

    textarea.form-control { min-height: 300px; line-height: 1.6; resize: vertical; }

    .file-input-wrapper {
        border: 2px dashed #ddd;
        padding: 30px;
        text-align: center;
        border-radius: 10px;
        cursor: pointer;
        transition: 0.3s;
    }
    .file-input-wrapper:hover { border-color: #3498db; background: #f9fcff; }

    .btn-group { display: flex; gap: 15px; margin-top: 30px; }

    .btn-save {
        background: #2ecc71;
        color: white;
        border: none;
        padding: 15px 40px;
        border-radius: 10px;
        font-weight: 700;
        cursor: pointer;
        font-size: 1rem;
        flex: 2;
    }

    .btn-cancel {
        background: #f8f9fa;
        color: #666;
        text-decoration: none;
        padding: 15px 30px;
        border-radius: 10px;
        text-align: center;
        font-weight: 600;
        flex: 1;
        border: 1px solid #ddd;
    }

    .error-msg { background: #fff5f5; color: #e74c3c; padding: 15px; border-radius: 8px; margin-bottom: 20px; border-left: 5px solid #e74c3c; }
</style>

<div class="admin-container">
    <div style="margin-bottom: 30px;">
        <a href="manage_blog.php" style="color: #3498db; text-decoration: none; font-weight: 600;">← Back to Articles</a>
        <h1 style="margin-top: 10px;">Write New Article</h1>
    </div>

    <?php if ($error): ?>
        <div class="error-msg"><?= $error ?></div>
    <?php endif; ?>

    <div class="editor-card">
        <form method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label>Article Title</label>
                <input type="text" name="title" class="form-control" placeholder="Enter a catchy title..." required>
            </div>

            <div class="form-group">
                <label>Featured Image</label>
                <div class="file-input-wrapper" onclick="document.getElementById('file-upload').click()">
                    <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: #ccc;"></i>
                    <p id="file-name" style="margin: 10px 0 0; color: #888;">Click to upload cover photo</p>
                    <input type="file" id="file-upload" name="image" style="display:none" onchange="updateFileName(this)" required>
                </div>
            </div>

            <div class="form-group">
                <label>Content</label>
                <textarea name="content" class="form-control" placeholder="Tell your story... (HTML tags are allowed)"></textarea>
                <small style="color: #999;">Tip: You can use &lt;p&gt;, &lt;h3&gt;, and &lt;strong&gt; tags for formatting.</small>
            </div>

            <div class="form-group" style="max-width: 200px;">
                <label>Publishing Status</label>
                <select name="status" class="form-control">
                    <option value="Published">Published</option>
                    <option value="Draft">Draft</option>
                </select>
            </div>

            <div class="btn-group">
                <a href="manage_blog.php" class="btn-cancel">Discard</a>
                <button type="submit" name="submit_post" class="btn-save">Publish Article</button>
            </div>

        </form>
    </div>
</div>

<script>
    function updateFileName(input) {
        const fileName = input.files[0].name;
        document.getElementById('file-name').textContent = "Selected: " + fileName;
        document.getElementById('file-name').style.color = "#2ecc71";
    }
</script>

<?php include '../includes/footer.php'; ?>