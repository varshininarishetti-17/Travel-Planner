<?php
include '../includes/db.php';
include '../includes/admin_check.php';
include 'admin_header.php';

// --- DELETE LOGIC ---
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM destination WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: manage_destinations.php?msg=Deleted");
}

// --- ADD LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_dest'])) {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $image = $_FILES['image']['name'];
    move_uploaded_file($_FILES['image']['tmp_name'], "../images/" . $image);

    $stmt = $conn->prepare("INSERT INTO destination (name, description, image) VALUES (?, ?, ?)");
    $stmt->execute([$name, $desc, $image]);
}

$destinations = $conn->query("SELECT * FROM destination ORDER BY id DESC")->fetchAll();
?>

<div style="margin-left:270px; padding:20px;">
    <h1>Manage Destinations</h1>

    <div style="background:#f4f4f4; padding:20px; border-radius:10px; margin-bottom:30px;">
        <h3>Add New Site</h3>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="name" placeholder="City/Country Name" required style="width:100%; padding:10px; margin-bottom:10px;">
            <textarea name="description" placeholder="Short description..." style="width:100%; padding:10px; margin-bottom:10px;"></textarea>
            <input type="file" name="image" required><br><br>
            <button type="submit" name="add_dest" style="background:green; color:white; padding:10px 20px; border:none; cursor:pointer;">Add Destination</button>
        </form>
    </div>

    <table style="width:100%; border-collapse:collapse; background:white;">
        <tr style="background:#333; color:white; text-align:left;">
            <th style="padding:10px;">ID</th>
            <th>Image</th>
            <th>Name</th>
            <th>Action</th>
        </tr>
        <?php foreach($destinations as $d): ?>
        <tr style="border-bottom:1px solid #ddd;">
            <td style="padding:10px;"><?= $d['id'] ?></td>
            <td><img src="../images/<?= $d['image'] ?>" width="60" style="border-radius:4px;"></td>
            <td><?= htmlspecialchars($d['name']) ?></td>
            <td>
                <a href="manage_destinations.php?delete=<?= $d['id'] ?>" 
                   onclick="return confirm('Deleting this site will leave packages without a home. Proceed?')" 
                   style="color:red; text-decoration:none; font-weight:bold;">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>