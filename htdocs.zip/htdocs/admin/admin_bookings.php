<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

require_once '../includes/db.php';
require_once '../includes/admin_check.php'; 
include 'admin_header.php';

$message = "";

// 1. UPDATE STATUS LOGIC
if (isset($_POST['update_status'])) {
    $stmt = $conn->prepare("UPDATE bookings SET status = :status WHERE id = :id");
    $stmt->execute(['status' => $_POST['status'], 'id' => $_POST['booking_id']]);
    $message = "Status updated successfully.";
}

// 2. DELETE LOGIC
if (isset($_POST['delete_booking'])) {
    $stmt = $conn->prepare("DELETE FROM bookings WHERE id = :id");
    $stmt->execute(['id' => $_POST['booking_id']]);
    $message = "Booking removed.";
}

/**
 * 3. THE "BULLETPROOF" QUERY
 * We use LEFT JOIN so that bookings show up even if the 
 * linked user or package has been deleted from other tables.
 */
$query = "SELECT 
            b.*, 
            u.full_name AS customer_name, 
            u.email AS customer_email, 
            p.name AS package_name, 
            p.price
          FROM bookings b 
          LEFT JOIN users u ON b.user_id = u.id 
          LEFT JOIN packages p ON b.package_id = p.id 
          ORDER BY b.created_at DESC";

try {
    $bookings = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Fallback if 'full_name' doesn't exist in your users table
    $query = str_replace('u.full_name', 'u.name', $query);
    $bookings = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
}
?>

<style>
    .admin-container { max-width: 1100px; margin: 40px auto; padding: 20px; font-family: sans-serif; }
    .stat-row { display: flex; gap: 20px; margin-bottom: 20px; }
    .stat-card { background: #fff; padding: 20px; flex: 1; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
    table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    th { background: #f4f4f4; padding: 15px; text-align: left; color: #666; font-size: 13px; }
    td { padding: 15px; border-top: 1px solid #eee; }
    .badge { padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; }
    .status-Pending { background: #ffeaa7; color: #d6a316; }
    .status-Confirmed { background: #55efc4; color: #00b894; }
    .status-Cancelled { background: #ff7675; color: #d63031; }
    .alert { padding: 15px; background: #d1f2eb; color: #16a085; border-radius: 5px; margin-bottom: 20px; }
</style>

<div class="admin-container">
    <h1>Manage Bookings</h1>

    <?php if ($message): ?>
        <div class="alert"><?= $message ?></div>
    <?php endif; ?>

    <div class="stat-row">
        <div class="stat-card">
            <small>Total Bookings</small>
            <h2><?= count($bookings) ?></h2>
        </div>
        <div class="stat-card">
            <small>Est. Revenue</small>
            <h2>$<?php 
                $rev = 0;
                foreach($bookings as $b) { $rev += (($b['price'] ?? 0) * ($b['num_people'] ?? 1)); }
                echo number_format($rev, 2);
            ?></h2>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Customer</th>
                <th>Package</th>
                <th>Travel Date</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($bookings as $row): ?>
            <tr>
                <td>#<?= $row['id'] ?></td>
                <td>
                    <strong><?= htmlspecialchars($row['customer_name'] ?? 'Guest/Deleted') ?></strong><br>
                    <small><?= htmlspecialchars($row['customer_email'] ?? 'N/A') ?></small>
                </td>
                <td>
                    <?= htmlspecialchars($row['package_name'] ?? 'Unknown Package') ?><br>
                    <small><?= $row['num_people'] ?> People</small>
                </td>
                <td><?= date("M d, Y", strtotime($row['travel_date'])) ?></td>
                <td><span class="badge status-<?= $row['status'] ?>"><?= $row['status'] ?></span></td>
                <td>
                    <form method="POST" style="display:inline-flex; gap:5px;">
                        <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                        <select name="status">
                            <option value="Pending" <?= $row['status']=='Pending'?'selected':'' ?>>Pending</option>
                            <option value="Confirmed" <?= $row['status']=='Confirmed'?'selected':'' ?>>Confirmed</option>
                            <option value="Cancelled" <?= $row['status']=='Cancelled'?'selected':'' ?>>Cancelled</option>
                        </select>
                        <button type="submit" name="update_status">Save</button>
                    </form>
                    
                    <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?');">
                        <input type="hidden" name="booking_id" value="<?= $row['id'] ?>">
                        <button type="submit" name="delete_booking" style="color:red; background:none; border:none; cursor:pointer;">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>

            <?php if(empty($bookings)): ?>
                <tr><td colspan="6" style="text-align:center; padding:30px;">No bookings found in database.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>