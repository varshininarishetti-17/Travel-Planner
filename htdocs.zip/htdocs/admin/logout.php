<?php
/**
 * 1. INITIALIZE SESSION
 */
session_start();

/**
 * 2. CLEAR ALL SESSION DATA
 * This removes all variables (like user_id, user_name, etc.)
 */
$_SESSION = array();

/**
 * 3. DESTROY THE COOKIE
 * If the session was using a cookie (standard behavior), 
 * we must tell the browser to delete it by setting its expiration to the past.
 */
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

/**
 * 4. CLEAR THE "REMEMBER ME" COOKIE
 * If you set a custom persistent cookie for your admin, clear it here.
 */
if (isset($_COOKIE['user_login'])) {
    setcookie("user_login", "", time() - 3600, "/");
}

/**
 * 5. DESTROY THE SESSION
 */
session_destroy();

/**
 * 6. REDIRECT
 * Send the user back to the login page or the main site.
 */
header("Location: ../login.php?logout=success");
exit;
?>