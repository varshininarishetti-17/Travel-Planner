<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

// 1. Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

// 2. Helper function to set active class
$current_page = basename($_SERVER['PHP_SELF']);
function is_active($page_name, $current_page) {
    return ($page_name === $current_page) ? 'active' : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Control Panel | TravelEase</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <style>
        :root {
            --admin-dark: #1e293b;
            --admin-blue: #3b82f6;
            --admin-border: #e2e8f0;
            --text-main: #f8fafc;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background-color: #f1f5f9; }

        .admin-navbar {
            background-color: var(--admin-dark);
            color: var(--text-main);
            padding: 0 2rem;
            height: 70px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: 0;
            z-index: 1000;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }

        .admin-logo {
            font-weight: 700;
            font-size: 1.4rem;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #fff;
            text-decoration: none;
        }

        .admin-logo span {
            background: var(--admin-blue);
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.7rem;
            text-transform: uppercase;
        }

        .admin-menu {
            display: flex;
            list-style: none;
            gap: 10px;
            height: 100%;
        }

        .admin-menu li { height: 100%; }

        .admin-menu a {
            color: #cbd5e1;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            padding: 0 15px;
            height: 100%;
            transition: 0.3s;
            border-bottom: 3px solid transparent;
        }

        /* The Active/Hover State */
        .admin-menu a:hover, 
        .admin-menu a.active {
            color: #fff;
            border-bottom: 3px solid var(--admin-blue);
            background: rgba(255,255,255,0.05);
        }

        .admin-menu i { margin-right: 8px; font-size: 1.1rem; }

        .admin-user-zone { display: flex; align-items: center; gap: 15px; }

        .view-site-btn {
            background: rgba(255,255,255,0.1);
            color: #fff;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.8rem;
            font-weight: 600;
        }

        .view-site-btn:hover { background: var(--admin-blue); }

        .logout-link { color: #ef4444; text-decoration: none; font-weight: 700; }

        @media (max-width: 900px) {
            .admin-menu span { display: none; }
            .admin-menu i { margin: 0; }
            .admin-navbar { padding: 0 1rem; }
        }
    </style>
</head>
<body>

<nav class="admin-navbar">
    <a href="index.php" class="admin-logo">
        <i class="fas fa-route"></i> Travel Planner <span>Admin</span>
    </a>

    <ul class="admin-menu">
        <li>
            <a href="index.php" class="<?= is_active('index.php', $current_page) ?>">
                <i class="fas fa-chart-line"></i> <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="manage_packages.php" class="<?= is_active('manage_packages.php', $current_page) ?>">
                <i class="fas fa-box"></i> <span>Packages</span>
            </a>
        </li>
        <li>
            <a href="admin_bookings.php" class="<?= is_active('admin_bookings.php', $current_page) ?>">
                <i class="fas fa-calendar-check"></i> <span>Bookings</span>
            </a>
        </li>
        <li>
            <a href="manage_users.php" class="<?= is_active('manage_users.php', $current_page) ?>">
                <i class="fas fa-users"></i> <span>Users</span>
            </a>
        </li>
    </ul>

    <div class="admin-user-zone">
        <a href="../index.php" class="view-site-btn" target="_blank">
            <i class="fas fa-external-link-alt"></i> View Site
        </a>
        <a href="../logout.php" class="logout-link" title="Logout">
            <i class="fas fa-sign-out-alt"></i>
        </a>
    </div>
</nav>