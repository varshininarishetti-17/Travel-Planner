<div style="background:#222; color:#fff; width:250px; padding:20px; min-height:100vh; float:left;">
    <h3>Admin Menu</h3>
    <ul style="list-style:none; padding:0; line-height:2.5;">
        <li><a href="index.php" style="color:#fff; text-decoration:none;">Dashboard</a></li>
        <li><a href="manage_destinations.php" style="color:#fff; text-decoration:none;">Destinations</a></li>
        <li><a href="manage_packages.php" style="color:#fff; text-decoration:none;">Travel Packages</a></li>
        <li><a href="manage_blog.php" style="color:#fff; text-decoration:none;">Blog Posts</a></li>
        <li><hr></li>
        <li><a href="../logout.php" style="color:#ff4d4d; text-decoration:none;">Logout</a></li>
    </ul>
</div>