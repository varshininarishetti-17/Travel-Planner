<?php
// 1. INITIALIZATION & SECURITY
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please_Login");
    exit();
}

require_once 'includes/db.php';
include 'includes/header.php';

$error = "";
$show_thanks = false; // Trigger for the popup

// 2. VALIDATE PACKAGE ID
$package_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$package_id) {
    echo "<div class='container'><p class='alert-error'>Invalid package selection. <a href='index.php'>Return Home</a></p></div>";
    include 'includes/footer.php';
    exit;
}

// 3. FETCH PACKAGE DATA
$stmt = $conn->prepare("SELECT p.*, d.name AS destination_name FROM packages p LEFT JOIN destination d ON p.destination_id = d.id WHERE p.id = :id");
$stmt->execute(['id' => $package_id]);
$package = $stmt->fetch(PDO::FETCH_ASSOC);

// 4. BOOKING LOGIC
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_booking'])) {
    $user_id = $_SESSION['user_id']; 
    $travel_date = $_POST['travel_date'];
    $num_people = (int)$_POST['num_people'];
    
    try {
        $stmtBooking = $conn->prepare("INSERT INTO bookings (user_id, package_id, travel_date, num_people, status) 
                                       VALUES (:user_id, :package_id, :travel_date, :num_people, 'Pending')");
        
        $success = $stmtBooking->execute([
            'user_id'     => $user_id,
            'package_id'  => $package_id, 
            'travel_date' => $travel_date, 
            'num_people'  => $num_people
        ]);

        if ($success) {
            $show_thanks = true; // Set trigger to true
        }
    } catch (PDOException $e) {
        $error = "Booking failed: " . $e->getMessage();
    }
}
?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
    :root { --primary: #2ecc71; --secondary: #3498db; --dark: #2c3e50; --light-bg: #f8f9fa; --white: #ffffff; --shadow: 0 10px 30px rgba(0,0,0,0.1); }
    body { background-color: var(--light-bg); font-family: 'Segoe UI', sans-serif; }
    .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
    .package-grid { display: grid; grid-template-columns: 1fr 400px; gap: 40px; }
    .package-main h1 { font-size: 2.5rem; color: var(--dark); margin: 10px 0 20px; font-weight: 800; }
    .dest-badge { background: var(--secondary); color: white; padding: 5px 15px; border-radius: 50px; font-size: 0.8rem; font-weight: 600; }
    .package-hero-img { width: 100%; height: 450px; object-fit: cover; border-radius: 20px; box-shadow: var(--shadow); margin-bottom: 30px; }
    .details-card { background: white; padding: 30px; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
    .booking-sidebar { background: var(--white); padding: 30px; border-radius: 20px; box-shadow: var(--shadow); position: sticky; top: 20px; }
    .price-tag { font-size: 2rem; font-weight: 800; color: var(--primary); margin-bottom: 20px; }
    .form-group { margin-bottom: 15px; }
    .form-group label { display: block; margin-bottom: 5px; font-weight: 600; }
    .form-input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 10px; }
    .btn-book { width: 100%; padding: 15px; background: var(--dark); color: white; border: none; border-radius: 10px; font-weight: 700; cursor: pointer; transition: 0.3s; }
    .btn-book:hover { background: var(--primary); transform: translateY(-2px); }
    @media (max-width: 992px) { .package-grid { grid-template-columns: 1fr; } .booking-sidebar { position: static; } }
</style>

<div class="container">
    <?php if ($error): ?>
        <div class="alert-error" style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 10px; margin-bottom: 20px;">
            <strong>⚠️ Error:</strong> <?= $error ?>
        </div>
    <?php endif; ?>

    <div class="package-grid">
        <main class="package-main">
            <span class="dest-badge">📍 <?= htmlspecialchars($package['destination_name'] ?? 'Global'); ?></span>
            <h1><?= htmlspecialchars($package['name']); ?></h1>
            <img src="images/<?= htmlspecialchars($package['image']); ?>" class="package-hero-img" onerror="this.src='https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1000&q=80'">
            <div class="details-card">
                <h3>Trip Description</h3>
                <div class="description"><?= nl2br(htmlspecialchars($package['description'])); ?></div>
            </div>
        </main>

        <aside>
            <div class="booking-sidebar">
                <div class="price-tag">$<?= number_format($package['price'], 2); ?> <small>/ person</small></div>
                <form method="POST">
                    <div class="form-group">
                        <label>Preferred Travel Date</label>
                        <input type="date" name="travel_date" class="form-input" min="<?= date('Y-m-d'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Number of Travelers</label>
                        <input type="number" name="num_people" class="form-input" min="1" max="20" value="1" required>
                    </div>
                    <button type="submit" name="submit_booking" class="btn-book">Request Booking</button>
                </form>
            </div>
        </aside>
    </div>
</div>

<script>
// If PHP says success, show the SweetAlert box
<?php if ($show_thanks): ?>
    Swal.fire({
        title: 'Thank You!',
        text: 'Your booking request for <?= htmlspecialchars($package['name']) ?> has been received. We will contact you soon!',
        icon: 'success',
        confirmButtonColor: '#2ecc71',
        confirmButtonText: 'Back to Packages'
    }).then((result) => {
        // After they click the button, navigate to the main packages page
        window.location.href = 'profile.php'; 
    });
<?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>