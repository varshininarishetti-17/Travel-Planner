<?php
// 1. Database & Header Integration
// include 'includes/db.php'; 
// include 'includes/header.php'; 

/** * Mock Connection for demonstration - Remove this block when including db.php
 * $conn = new PDO("mysql:host=localhost;dbname=travel_db", "root", "");
**/

// 2. Search Logic
$isSearch = !empty($_GET['search']);
$searchTerm = $isSearch ? trim($_GET['search']) : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Explore Destinations | Travel Experts</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        /* --- CSS Variables --- */
        :root {
            --primary-color: #007BFF;
            --accent-color: #0056b3;
            --bg-light: #f8f9fa;
            --text-dark: #333;
            --text-muted: #666;
            --white: #ffffff;
            --shadow: 0 10px 20px rgba(0,0,0,0.08);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #fff;
            color: var(--text-dark);
            margin: 0;
            padding: 0;
        }

        /* --- Hero Section --- */
        .search-hero {
            padding: 80px 20px;
            text-align: center;
            background: linear-gradient(135deg, #f1f3f5 0%, #e9ecef 100%);
            border-bottom: 1px solid #dee2e6;
        }

        .search-hero h1 {
            font-size: 2.8rem;
            margin-bottom: 25px;
            font-weight: 600;
            letter-spacing: -0.5px;
        }

        .search-container {
            display: flex;
            justify-content: center;
            max-width: 650px;
            margin: 0 auto;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 18px 30px;
            font-size: 1.1rem;
            border: 2px solid transparent;
            border-radius: 50px;
            box-shadow: var(--shadow);
            outline: none;
            transition: var(--transition);
        }

        .search-input:focus {
            border-color: var(--primary-color);
            background: var(--white);
        }

        .search-btn {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            padding: 12px 28px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 40px;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }

        .search-btn:hover { background-color: var(--accent-color); }

        /* --- Grid Layout --- */
        .content-section {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 20px;
        }

        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
        }

        .section-title {
            font-size: 1.8rem;
            border-left: 5px solid var(--primary-color);
            padding-left: 15px;
            margin: 0;
        }

        .reset-link {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .destinations-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 35px;
        }

        /* --- Card Styling --- */
        .dest-card {
            background: var(--white);
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.04);
            transition: var(--transition);
            border: 1px solid #f1f1f1;
            display: flex;
            flex-direction: column;
        }

        .dest-card:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow);
        }

        .image-wrapper {
            position: relative;
            height: 240px;
            overflow: hidden;
        }

        .image-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s cubic-bezier(0.165, 0.84, 0.44, 1);
        }

        .dest-card:hover img { transform: scale(1.08); }

        .location-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(255, 255, 255, 0.9);
            color: var(--text-dark);
            padding: 6px 14px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: uppercase;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .card-body {
            padding: 25px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }

        .card-body h3 { margin: 0 0 12px 0; font-size: 1.4rem; color: #1a1a1a; }

        .card-body p {
            font-size: 0.95rem;
            color: var(--text-muted);
            line-height: 1.6;
            margin-bottom: 25px;
        }

        .details-link {
            margin-top: auto;
            text-align: center;
            padding: 14px;
            background-color: #f8f9fa;
            color: var(--text-dark);
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            border: 1px solid #eee;
            transition: var(--transition);
        }

        .details-link:hover {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .empty-state {
            text-align: center;
            grid-column: 1 / -1;
            padding: 80px 20px;
            background: var(--bg-light);
            border-radius: 20px;
        }

        @media (max-width: 600px) {
            .search-hero h1 { font-size: 2rem; }
            .search-input { padding: 15px 20px; font-size: 1rem; }
            .search-btn { padding: 10px 20px; font-size: 0.9rem; }
        }
    </style>
</head>
<body>

<header class="search-hero">
    <h1>Find Your Next Adventure</h1>
    
    <form method="GET" action="" class="search-container">
        <input type="text" name="search" class="search-input" 
               placeholder="Search destinations or locations..." 
               value="<?= htmlspecialchars($searchTerm) ?>" required>
        <button type="submit" class="search-btn">Search</button>
    </form>
</header>

<main class="content-section">
    <div class="section-header">
        <h2 class="section-title">
            <?= $isSearch ? "Search Results" : "Top Destinations"; ?>
        </h2>
        <?php if($isSearch): ?>
            <a href="destinations.php" class="reset-link">← Clear Search</a>
        <?php endif; ?>
    </div>

    <div class="destinations-grid">
        <?php
        try {
            // 3. Database Execution
            if ($isSearch) {
                $stmt = $conn->prepare("SELECT * FROM destinations WHERE name LIKE :search OR location LIKE :search ORDER BY created_at DESC");
                $stmt->execute(['search' => "%$searchTerm%"]);
            } else {
                $stmt = $conn->query("SELECT * FROM destinations ORDER BY created_at DESC");
            }

            if ($stmt && $stmt->rowCount() > 0) {
                while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    // Fallback for image
                    $imgSrc = !empty($row['image']) ? "images/".htmlspecialchars($row['image']) : "https://via.placeholder.com/400x300?text=No+Image";
                    ?>
                    <article class="dest-card">
                        <div class="image-wrapper">
                            <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($row['name']) ?>">
                            <div class="location-badge">📍 <?= htmlspecialchars($row['location']) ?></div>
                        </div>
                        <div class="card-body">
                            <h3><?= htmlspecialchars($row['name']) ?></h3>
                            <p><?= htmlspecialchars(substr($row['description'], 0, 100)) ?>...</p>
                            <a href="destination_detail.php?id=<?= $row['id'] ?>" class="details-link">Explore More</a>
                        </div>
                    </article>
                    <?php
                }
            } else {
                echo "<div class='empty-state'>
                        <h3 style='font-size: 1.5rem;'>No matches found for \"".htmlspecialchars($searchTerm)."\"</h3>
                        <p>We couldn't find what you're looking for. Check your spelling or try searching for a country.</p>
                        <a href='destinations.php' class='details-link' style='display:inline-block; margin-top:15px;'>Browse All Destinations</a>
                      </div>";
            }
        } catch (Exception $e) {
            echo "<p class='empty-state'>Please connect to your database to view destinations.</p>";
        }
        ?>
    </div>
</main>

<?php // include 'includes/footer.php'; ?>

</body>
</html>