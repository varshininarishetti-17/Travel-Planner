<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please_Login");
    exit(); // Always call exit() after a header redirect
}
// 1. Database Connection & Header
include 'includes/db.php';
include 'includes/header.php';

// 2. Fetch all categories for the filter dropdown
$catStmt = $conn->query("SELECT * FROM blog_categories ORDER BY name ASC");
$categories = $catStmt->fetchAll(PDO::FETCH_ASSOC);

// 3. Handle Filters (Search and Category)
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category_id = isset($_GET['category']) ? $_GET['category'] : '';

// 4. Build the Query
// Note: We use "WHERE 1=1" so we can dynamically append AND conditions
$query = "SELECT bp.*, bc.name AS category_name 
          FROM blog_posts bp
          LEFT JOIN blog_categories bc ON bp.category_id = bc.id
          WHERE 1=1"; 

$params = [];

// If you decide to add a 'status' column later, uncomment the line below:
// $query .= " AND bp.status = 'Published'";

if (!empty($search)) {
    $query .= " AND (bp.title LIKE :search OR bp.content LIKE :search)";
    $params['search'] = "%$search%";
}

if (!empty($category_id)) {
    $query .= " AND bp.category_id = :category_id";
    $params['category_id'] = $category_id;
}

$query .= " ORDER BY bp.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
    :root {
        --blog-primary: #2e7d32;
        --blog-dark: #2c3e50;
        --blog-gray: #7f8c8d;
        --blog-light: #f8f9fa;
        --blog-shadow: 0 10px 30px rgba(0,0,0,0.08);
    }

    /* --- HERO SECTION --- */
    .blog-hero {
        padding: 80px 20px;
        text-align: center;
        background: linear-gradient(rgba(46, 125, 50, 0.05), rgba(46, 125, 50, 0.02));
        border-bottom: 1px solid #eee;
    }
    .blog-hero h1 { font-size: 3rem; color: var(--blog-dark); margin-bottom: 10px; }
    .blog-hero p { color: var(--blog-gray); font-size: 1.1rem; }

    /* --- FILTER FORM --- */
    .filter-container {
        max-width: 800px;
        margin: -40px auto 50px;
        background: white;
        padding: 20px;
        border-radius: 15px;
        box-shadow: var(--blog-shadow);
        display: flex;
        gap: 15px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .filter-container input, .filter-container select {
        padding: 12px 20px;
        border: 1px solid #ddd;
        border-radius: 8px;
        flex: 1;
        min-width: 200px;
        outline: none;
        transition: border 0.3s;
    }
    .filter-container input:focus { border-color: var(--blog-primary); }
    .filter-container button {
        background: var(--blog-primary);
        color: white;
        border: none;
        padding: 12px 30px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.3s;
    }
    .filter-container button:hover { background: #1b5e20; transform: translateY(-2px); }

    /* --- BLOG GRID --- */
    .blog-grid {
        max-width: 1200px;
        margin: 0 auto 80px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
        gap: 40px;
        padding: 0 20px;
    }
    .blog-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 4px 15px rgba(0,0,0,0.05);
        transition: 0.3s;
        display: flex;
        flex-direction: column;
        border: 1px solid #f0f0f0;
    }
    .blog-card:hover { transform: translateY(-10px); box-shadow: var(--blog-shadow); }
    
    .card-img-wrapper { height: 220px; overflow: hidden; position: relative; }
    .card-img-wrapper img { width: 100%; height: 100%; object-fit: cover; transition: 0.5s; }
    .blog-card:hover .card-img-wrapper img { transform: scale(1.1); }
    
    .category-badge {
        position: absolute; top: 15px; left: 15px;
        background: rgba(46, 125, 50, 0.9);
        color: white; padding: 5px 12px; border-radius: 50px;
        font-size: 0.75rem; font-weight: 600; text-transform: uppercase;
    }

    .blog-content { padding: 25px; flex-grow: 1; display: flex; flex-direction: column; }
    .blog-date { font-size: 0.85rem; color: var(--blog-gray); margin-bottom: 10px; }
    .blog-content h3 { font-size: 1.4rem; color: var(--blog-dark); margin-bottom: 15px; line-height: 1.3; }
    .blog-excerpt { color: #555; font-size: 0.95rem; line-height: 1.6; margin-bottom: 20px; }

    .read-btn {
        margin-top: auto;
        color: var(--blog-primary);
        text-decoration: none;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 8px;
        transition: 0.2s;
    }
    .read-btn:hover { gap: 12px; }

    @media (max-width: 768px) {
        .blog-hero h1 { font-size: 2.2rem; }
        .filter-container { margin: 20px; }
    }
</style>

<section class="blog-hero">
    <h1>Explore Our Stories</h1>
    <p>Handpicked travel guides and inspiration for your next adventure.</p>
</section>

<div class="filter-container">
    <form method="GET" action="blog.php" style="display: contents;">
        <input type="text" name="search" placeholder="Search for topics..." value="<?= htmlspecialchars($search); ?>">
        
        <select name="category">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?= $cat['id']; ?>" <?= ($category_id == $cat['id']) ? 'selected' : ''; ?>>
                    <?= htmlspecialchars($cat['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <button type="submit">Filter Posts</button>
    </form>
</div>

<section class="blog-grid">
    <?php if ($posts): ?>
        <?php foreach($posts as $post): ?>
            <article class="blog-card">
                <div class="card-img-wrapper">
                    <?php 
                        $imgSrc = !empty($post['image']) ? "images/".$post['image'] : "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=800&q=80";
                    ?>
                    <img src="<?= $imgSrc ?>" alt="<?= htmlspecialchars($post['title']) ?>" 
                         onerror="this.src='https://via.placeholder.com/400x250?text=Travel+Blog'">
                    <span class="category-badge"><?= htmlspecialchars($post['category_name'] ?? 'Travel') ?></span>
                </div>
                
                <div class="blog-content">
                    <div class="blog-date">
                        <i class="far fa-calendar-alt"></i> <?= date('M j, Y', strtotime($post['created_at'])) ?>
                    </div>
                    <h3><?= htmlspecialchars($post['title']) ?></h3>
                    <p class="blog-excerpt">
                        <?= htmlspecialchars(substr(strip_tags($post['content']), 0, 120)) ?>...
                    </p>
                    <a href="blog_detail.php?id=<?= $post['id'] ?>" class="read-btn">
                        Read Full Story <i class="fas fa-arrow-right"></i>
                    </a>
                </div>
            </article>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="grid-column: 1 / -1; text-align: center; padding: 100px 20px;">
            <i class="fas fa-search" style="font-size: 4rem; color: #eee; margin-bottom: 20px;"></i>
            <h2 style="color: #ccc;">No posts matched your criteria</h2>
            <p style="color: #999;">Try a different keyword or category.</p>
            <a href="blog.php" style="color: var(--blog-primary); text-decoration: none; margin-top: 20px; display: inline-block;">Clear Filters</a>
        </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>