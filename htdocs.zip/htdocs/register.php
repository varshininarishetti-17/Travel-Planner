<?php
include 'includes/db.php';
include 'includes/guest_header.php';

$error = "";
$success = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($name) && !empty($email) && !empty($password)) {
        // Check if email already exists
        $checkEmail = $conn->prepare("SELECT id FROM users WHERE email = :email");
        $checkEmail->execute(['email' => $email]);
        
        if ($checkEmail->rowCount() > 0) {
            $error = "This email is already registered.";
        } else {
            // Hash the password before saving
            $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (:name, :email, :password)");
            if ($stmt->execute(['name' => $name, 'email' => $email, 'password' => $hashedPassword])) {
                $success = "Registration successful! <a href='login.php'>Login here</a>";
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    } else {
        $error = "Please fill in all fields.";
    }
}
?>

<div style="max-width: 400px; margin: 60px auto; padding: 30px; border: 1px solid #eee; border-radius: 15px; box-shadow: var(--shadow);">
    <h2 style="text-align:center; margin-bottom: 20px;">Create Account</h2>

    <?php if($error): ?>
        <p style="color: #721c24; background: #f8d7da; padding: 10px; border-radius: 5px;"><?= $error ?></p>
    <?php endif; ?>

    <?php if($success): ?>
        <p style="color: #155724; background: #d4edda; padding: 10px; border-radius: 5px;"><?= $success ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label style="display:block; margin-bottom:5px;">Full Name</label>
        <input type="text" name="name" required style="width:100%; padding:10px; margin-bottom:15px; border:1px solid #ddd; border-radius:5px;">

        <label style="display:block; margin-bottom:5px;">Email Address</label>
        <input type="email" name="email" required style="width:100%; padding:10px; margin-bottom:15px; border:1px solid #ddd; border-radius:5px;">

        <label style="display:block; margin-bottom:5px;">Password</label>
        <input type="password" name="password" required style="width:100%; padding:10px; margin-bottom:20px; border:1px solid #ddd; border-radius:5px;">

        <button type="submit" style="width:100%; padding:12px; background:var(--primary); color:white; border:none; border-radius:5px; cursor:pointer; font-weight:600;">Register</button>
    </form>
    <p style="text-align:center; margin-top:15px;">Already have an account? <a href="login.php">Login</a></p>
</div>

<?php include 'includes/footer.php'; ?>