<?php
include 'includes/db.php';
include 'includes/header.php';

// Logic for Contact Form
$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_msg = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = "Invalid email address.";
    } else {
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, subject, message) VALUES (:name, :email, :subject, :message)");
        $stmt->execute(['name' => $name, 'email' => $email, 'subject' => $subject, 'message' => $message]);
        $success_msg = "Thank you! Your message has been sent.";
    }
}
?>

<style>
    :root {
        --primary: #007BFF;
        --dark: #333;
        --light: #f4f4f4;
        --white: #ffffff;
        --shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: var(--dark); line-height: 1.6; }

    /* Header Styles */
    .page-header { background: #e9ecef; padding: 60px 20px; text-align: center; border-bottom: 1px solid #ddd; }
    .page-header h1 { font-size: 2.5rem; margin-bottom: 10px; color: var(--dark); }
    
    /* Search Form */
    .search-box { margin-top: 25px; }
    .search-box input { padding: 12px 20px; width: 300px; border: 1px solid #ccc; border-radius: 25px 0 0 25px; outline: none; }
    .search-box button { padding: 12px 25px; background: var(--primary); color: #fff; border: none; border-radius: 0 25px 25px 0; cursor: pointer; transition: 0.3s; }
    .search-box button:hover { background: #0056b3; }

    /* Blog Grid */
    .container { max-width: 1200px; margin: 40px auto; padding: 0 20px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px; }
    
    .blog-card { background: var(--white); border-radius: 10px; overflow: hidden; box-shadow: var(--shadow); transition: 0.3s; }
    .blog-card:hover { transform: translateY(-5px); }
    .blog-card img { width: 100%; height: 200px; object-fit: cover; }
    .blog-card-content { padding: 20px; }
    .blog-card-content h3 { margin: 0 0 10px; font-size: 1.3rem; }
    .meta { font-size: 0.85rem; color: #777; margin-bottom: 15px; }
    
    .btn-read { display: inline-block; padding: 8px 20px; background: var(--primary); color: #fff; text-decoration: none; border-radius: 5px; font-weight: 500; }

    /* Contact Form Styles */
    .contact-section { background: var(--light); padding: 60px 20px; }
    .contact-form { max-width: 700px; margin: 0 auto; background: var(--white); padding: 40px; border-radius: 10px; box-shadow: var(--shadow); }
    .form-group { margin-bottom: 20px; }
    .form-group input, .form-group textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }
    .btn-submit { width: 100%; padding: 15px; background: var(--primary); color: #fff; border: none; border-radius: 5px; font-size: 1rem; cursor: pointer; }
    
    .alert { padding: 15px; border-radius: 5px; margin-bottom: 20px; text-align: center; }
    .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }

    .office-info { margin-top: 40px; text-align: center; }
</style>

<section class="page-header">
    <h1>Travel Blog & Guides</h1>
    <p>Read our latest travel tips, guides, and stories!</p>

    <form method="GET" action="blog.php" class="search-box">
        <input type="text" name="search" placeholder="Search blog posts..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
        <button type="submit">Search</button>
    </form>
</section>

<div class="container">
    <div class="grid">
        <?php
        if (isset($_GET['search']) && !empty($_GET['search'])) {
            $search = $_GET['search'];
            $stmt = $conn->prepare("SELECT * FROM blog_posts WHERE title LIKE :search OR content LIKE :search ORDER BY created_at DESC");
            $stmt->execute(['search' => "%$search%"]);
        } else {
            $stmt = $conn->query("SELECT * FROM blog_posts ORDER BY created_at DESC");
        }

        if ($stmt->rowCount() > 0):
            while($post = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                <article class="blog-card">
                    <img src="images/<?= htmlspecialchars($post['image']) ?>" alt="<?= htmlspecialchars($post['title']) ?>">
                    <div class="blog-card-content">
                        <h3><?= htmlspecialchars($post['title']) ?></h3>
                        <div class="meta">By <?= htmlspecialchars($post['author']) ?> | <?= date('M j, Y', strtotime($post['created_at'])) ?></div>
                        <p><?= htmlspecialchars(substr($post['content'], 0, 100)) ?>...</p>
                        <a href="blog_detail.php?id=<?= $post['id'] ?>" class="btn-read">Read More</a>
                    </div>
                </article>
            <?php endwhile;
        else: ?>
            <p style="text-align:center; grid-column: 1 / -1;">No blog posts found matching your search.</p>
        <?php endif; ?>
    </div>
</div>

<hr style="border: 0; height: 1px; background: #eee; margin: 40px 0;">

<section class="contact-section">
    <div class="page-header" style="background:none; border:none; padding: 0 0 40px 0;">
        <h2>Contact Us</h2>
        <p>Questions about a trip? We're here to help.</p>
    </div>

    <div class="contact-form">
        <?php if ($error_msg): ?>
            <div class="alert alert-error"><?= $error_msg ?></div>
        <?php endif; ?>
        
        <?php if ($success_msg): ?>
            <div class="alert alert-success"><?= $success_msg ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <input type="text" name="name" placeholder="Your Name" required>
            </div>
            <div class="form-group">
                <input type="email" name="email" placeholder="Your Email" required>
            </div>
            <div class="form-group">
                <input type="text" name="subject" placeholder="Subject" required>
            </div>
            <div class="form-group">
                <textarea name="message" placeholder="Your Message" required style="height: 150px;"></textarea>
            </div>
            <button type="submit" name="submit_contact" class="btn-submit">Send Message</button>
        </form>
    </div>

    <div class="office-info">
        <h3>Our Office</h3>
        <p><strong>Email:</strong> info@travelwebsite.com<br>
        <strong>Phone:</strong> +123-456-7890<br>
        <strong>Address:</strong> 123 Travel Street, Adventure City</p>
    </div>
</section>

<?php include 'includes/footer.php'; ?>