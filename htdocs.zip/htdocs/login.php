<?php
// 1. Start the session at the very top
session_start();

// 2. Include your database connection and global header
include 'includes/db.php';
include 'includes/guest_header.php';

$error = "";

// 3. Process the login form when submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($email) && !empty($password)) {
        try {
            // Prepare statement to find user by email
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email LIMIT 1");
            $stmt->execute(['email' => $email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Verify if user exists and password matches the hash
            if ($user && password_verify($password, $user['password'])) {
                
                // Success! Regenerate session ID to prevent session fixation
                session_regenerate_id(true);

                // Store user data in Session variables
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                $_SESSION['logged_in'] = true;

                // --- DYNAMIC ROLE CHECK ---
                // We pull the 'role' directly from the database column
                $_SESSION['role'] = $user['role']; 

                if ($_SESSION['role'] === 'admin') {
                    header("Location: admin/index.php");
                } else {
                    header("Location: dashboard.php");
                }
                exit;

            } else {
                $error = "Invalid email address or password.";
            }
        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Please enter both email and password.";
    }
}
?>

<style>
    .login-container {
        max-width: 400px;
        margin: 80px auto;
        padding: 40px;
        background: #fff;
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0,0,0,0.1);
        border: 1px solid #eee;
    }
    .login-container h2 { text-align: center; margin-bottom: 30px; color: #333; font-weight: 700; }
    .form-group { margin-bottom: 20px; }
    .form-group label { display: block; margin-bottom: 8px; font-weight: 600; font-size: 0.9rem; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 1rem; transition: border-color 0.3s; }
    .form-control:focus { border-color: #007BFF; outline: none; }
    .btn-login { width: 100%; padding: 12px; background: #007BFF; color: white; border: none; border-radius: 8px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: background 0.3s; }
    .btn-login:hover { background: #0056b3; }
    .error-msg { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 8px; margin-bottom: 20px; font-size: 0.9rem; text-align: center; }
</style>

<main>
    <div class="login-container">
        <h2>Sign In</h2>

        <?php if ($error): ?>
            <div class="error-msg">
                <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="name@example.com" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="••••••••" required>
            </div>

            <button type="submit" class="btn-login">Login to Account</button>
        </form>

        <div style="text-align:center; margin-top:20px; font-size:0.9rem; color:#666;">
            Don't have an account? <a href="register.php" style="color:#007BFF; text-decoration:none; font-weight:600;">Create one here</a>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>