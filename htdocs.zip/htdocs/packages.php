

<?php
    
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php?msg=Please_Login");
    exit(); // Always call exit() after a header redirect
}

include 'includes/db.php';
include 'includes/header.php'; 

// 1. Get and sanitize search term
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';

// 2. Base Query
$query = "SELECT p.*, d.name AS destination_name 
          FROM packages p 
          LEFT JOIN destination d ON p.destination_id = d.id";

try {
    if (!empty($searchTerm)) {
        // Search in both package name and destination name
        $stmt = $conn->prepare($query . " WHERE p.name LIKE :s OR d.name LIKE :s ORDER BY p.id DESC");
        $stmt->execute(['s' => "%$searchTerm%"]);
    } else {
        $stmt = $conn->query($query . " ORDER BY p.id DESC");
    }
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<style>
    :root {
        --primary: #007BFF;
        --accent: #2ecc71;
        --dark: #1a1a1a;
        --bg-gray: #f4f7f6;
    }

    body { background-color: var(--bg-gray); }

    /* --- HERO SEARCH SECTION --- */
    .packages-hero {
        background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('images/hero-landscape.jpg') center/cover;
        padding: 80px 20px;
        text-align: center;
        color: white;
        border-radius: 0 0 40px 40px;
    }

    .packages-hero h1 { font-size: 3rem; font-weight: 800; margin-bottom: 10px; }

    .search-container {
        max-width: 700px;
        margin: 30px auto 0;
        background: white;
        padding: 6px;
        border-radius: 50px;
        display: flex;
        box-shadow: 0 15px 35px rgba(0,0,0,0.2);
    }

    .search-container input {
        flex: 1;
        border: none;
        padding: 15px 25px;
        outline: none;
        font-size: 1rem;
        border-radius: 50px 0 0 50px;
    }

    .search-container button {
        background: var(--primary);
        color: white;
        border: none;
        padding: 0 40px;
        border-radius: 50px;
        font-weight: 600;
        cursor: pointer;
        transition: 0.3s;
    }

    .search-container button:hover { background: #0056b3; }

    /* --- RESULTS GRID --- */
    .results-container { max-width: 1200px; margin: 60px auto; padding: 0 20px; }

    .grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr); /* 3 items per row */
        gap: 30px;
    }

    .pkg-card {
        background: white;
        border-radius: 20px;
        overflow: hidden;
        border: 1px solid #eee;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
        display: flex;
        flex-direction: column;
    }

    .pkg-card:hover { 
        transform: translateY(-10px); 
        box-shadow: 0 20px 40px rgba(0,0,0,0.1); 
    }

    .pkg-img { width: 100%; height: 230px; object-fit: cover; }

    .pkg-body { padding: 25px; flex-grow: 1; }

    .dest-label { 
        color: var(--primary); 
        font-weight: 700; 
        font-size: 0.75rem; 
        text-transform: uppercase; 
        letter-spacing: 1px;
    }

    .pkg-title { font-size: 1.4rem; margin: 10px 0; color: var(--dark); font-weight: 700; }

    .pkg-info { color: #777; font-size: 0.9rem; margin-bottom: 20px; }

    .pkg-footer { 
        display: flex; 
        justify-content: space-between; 
        align-items: center; 
        padding-top: 15px; 
        border-top: 1px solid #f0f0f0; 
    }

    .price-tag { font-size: 1.6rem; font-weight: 800; color: var(--accent); }

    .btn-details {
        background: var(--dark);
        color: white;
        text-decoration: none;
        padding: 10px 25px;
        border-radius: 10px;
        font-size: 0.9rem;
        font-weight: 600;
        transition: 0.3s;
    }

    .btn-details:hover { background: var(--primary); }

    /* Responsive */
    @media (max-width: 992px) { .grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 650px) { 
        .grid { grid-template-columns: 1fr; }
        .packages-hero h1 { font-size: 2rem; }
    }
</style>

<section class="packages-hero">
    <h1>Explore Our Packages</h1>
    <p>Hand-picked adventures for every type of traveler.</p>
    <form class="search-container" method="GET">
        <input type="text" name="search" placeholder="Search by destination or package name..." value="<?= htmlspecialchars($searchTerm) ?>">
        <button type="submit">Search</button>
    </form>
</section>

<div class="results-container">
    <?php if (!empty($searchTerm)): ?>
        <p style="margin-bottom: 30px; font-size: 1.1rem;">
            Showing results for: <strong>"<?= htmlspecialchars($searchTerm) ?>"</strong>
        </p>
    <?php endif; ?>

    <div class="grid">
        <?php 
        $found = false;
        while($pkg = $stmt->fetch(PDO::FETCH_ASSOC)): 
            $found = true;
        ?>
            <div class="pkg-card">
                <img src="images/<?= htmlspecialchars($pkg['image']) ?>" 
                     class="pkg-img" 
                     alt="<?= htmlspecialchars($pkg['name']) ?>" 
                     onerror="this.src='https://via.placeholder.com/400x250?text=Image+Coming+Soon'">
                
                <div class="pkg-body">
                    <span class="dest-label">
                        <i class="fas fa-map-marker-alt"></i> <?= htmlspecialchars($pkg['destination_name'] ?? 'World') ?>
                    </span>
                    <h3 class="pkg-title"><?= htmlspecialchars($pkg['name']) ?></h3>
                    <p class="pkg-info">
                        <i class="far fa-clock"></i> <?= htmlspecialchars($pkg['duration']) ?>
                    </p>
                    
                    <div class="pkg-footer">
                        <div class="price-tag">$<?= number_format($pkg['price'], 2) ?></div>
                        <a href="package_detail.php?id=<?= $pkg['id'] ?>" class="btn-details">View Details</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>

    <?php if (!$found): ?>
        <div style="text-align: center; padding: 100px 20px;">
            <i class="fas fa-search" style="font-size: 4rem; color: #ddd; margin-bottom: 20px;"></i>
            <h3>No Adventures Found</h3>
            <p>We couldn't find anything matching "<?= htmlspecialchars($searchTerm) ?>".</p>
            <a href="packages.php" style="color: var(--primary); text-decoration: none; font-weight: bold; margin-top: 20px; display: inline-block;">Clear Search & View All</a>
        </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>